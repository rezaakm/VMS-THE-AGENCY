# Quick verification script

Write-Host "🔍 Verifying Installation Status..." -ForegroundColor Cyan
Write-Host ""

$allGood = $true

# Check Node.js
Write-Host "Checking Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ Node.js: $nodeVersion" -ForegroundColor Green
        $npmVersion = npm --version 2>&1
        Write-Host "  ✅ npm: $npmVersion" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Node.js: NOT INSTALLED" -ForegroundColor Red
        $allGood = $false
    }
} catch {
    Write-Host "  ❌ Node.js: NOT INSTALLED" -ForegroundColor Red
    Write-Host "     Please install from: https://nodejs.org/" -ForegroundColor Gray
    $allGood = $false
}

Write-Host ""

# Check PostgreSQL
Write-Host "Checking PostgreSQL..." -ForegroundColor Yellow
try {
    $psqlVersion = psql --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ PostgreSQL: $psqlVersion" -ForegroundColor Green
    } else {
        Write-Host "  ❌ PostgreSQL: NOT INSTALLED" -ForegroundColor Red
        $allGood = $false
    }
} catch {
    Write-Host "  ❌ PostgreSQL: NOT INSTALLED" -ForegroundColor Red
    Write-Host "     Please install from: https://www.postgresql.org/download/windows/" -ForegroundColor Gray
    $allGood = $false
}

Write-Host ""

if ($allGood) {
    Write-Host "🎉 All prerequisites are installed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "You can now proceed with setting up the VMS project." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Next: See QUICK_START.md or follow:" -ForegroundColor Cyan
    Write-Host "  cd packages\backend" -ForegroundColor White
    Write-Host "  npm install" -ForegroundColor White
} else {
    Write-Host "⚠️  Some prerequisites are missing." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please install the missing components:" -ForegroundColor Yellow
    Write-Host "  - Run: powershell -ExecutionPolicy Bypass -File .\OPEN_DOWNLOADS.ps1" -ForegroundColor White
    Write-Host "  - Or see: INSTALL_STEPS.txt" -ForegroundColor White
}

Write-Host ""

