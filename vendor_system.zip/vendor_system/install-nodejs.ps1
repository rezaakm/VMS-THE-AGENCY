# PowerShell script to help install Node.js

Write-Host "📦 Node.js Installation Helper" -ForegroundColor Cyan
Write-Host ""

# Check if already installed
$nodeVersion = Get-Command node -ErrorAction SilentlyContinue
if ($nodeVersion) {
    Write-Host "✅ Node.js is already installed!" -ForegroundColor Green
    Write-Host "   Version: $(node --version)" -ForegroundColor Gray
    Write-Host "   npm Version: $(npm --version)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Node.js is ready to use! 🎉" -ForegroundColor Green
    exit 0
}

Write-Host "Node.js is not installed." -ForegroundColor Yellow
Write-Host ""

# Check for winget
$winget = Get-Command winget -ErrorAction SilentlyContinue

if ($winget) {
    Write-Host "Detected: Windows Package Manager (winget)" -ForegroundColor Green
    Write-Host ""
    Write-Host "Would you like to install Node.js LTS using winget?" -ForegroundColor Yellow
    Write-Host "1. Yes, install using winget (Automatic)"
    Write-Host "2. No, I'll install manually"
    Write-Host ""
    $choice = Read-Host "Enter choice (1 or 2)"
    
    if ($choice -eq "1") {
        Write-Host ""
        Write-Host "Installing Node.js LTS..." -ForegroundColor Cyan
        try {
            winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
            Write-Host ""
            Write-Host "✅ Node.js installed successfully!" -ForegroundColor Green
            Write-Host ""
            Write-Host "Please close and reopen PowerShell, then run:" -ForegroundColor Yellow
            Write-Host "  node --version" -ForegroundColor White
            Write-Host "  npm --version" -ForegroundColor White
        } catch {
            Write-Host "❌ Installation failed: $_" -ForegroundColor Red
            Write-Host ""
            Write-Host "Please install manually from: https://nodejs.org/" -ForegroundColor Yellow
        }
        exit 0
    }
}

# Check for Chocolatey
$choco = Get-Command choco -ErrorAction SilentlyContinue

if ($choco) {
    Write-Host "Detected: Chocolatey Package Manager" -ForegroundColor Green
    Write-Host ""
    Write-Host "Would you like to install Node.js LTS using Chocolatey?" -ForegroundColor Yellow
    Write-Host "1. Yes, install using Chocolatey (Automatic)"
    Write-Host "2. No, I'll install manually"
    Write-Host ""
    $choice = Read-Host "Enter choice (1 or 2)"
    
    if ($choice -eq "1") {
        Write-Host ""
        Write-Host "Installing Node.js LTS..." -ForegroundColor Cyan
        try {
            choco install nodejs-lts -y
            Write-Host ""
            Write-Host "✅ Node.js installed successfully!" -ForegroundColor Green
            Write-Host ""
            Write-Host "Please close and reopen PowerShell, then run:" -ForegroundColor Yellow
            Write-Host "  node --version" -ForegroundColor White
            Write-Host "  npm --version" -ForegroundColor White
        } catch {
            Write-Host "❌ Installation failed: $_" -ForegroundColor Red
            Write-Host ""
            Write-Host "Please install manually from: https://nodejs.org/" -ForegroundColor Yellow
        }
        exit 0
    }
}

# Manual installation guide
Write-Host ""
Write-Host "📥 Manual Installation Required" -ForegroundColor Yellow
Write-Host ""
Write-Host "Please install Node.js manually:" -ForegroundColor White
Write-Host ""
Write-Host "1. Visit: https://nodejs.org/" -ForegroundColor Cyan
Write-Host "2. Download the LTS version (Recommended)" -ForegroundColor Cyan
Write-Host "3. Run the installer (.msi file)" -ForegroundColor Cyan
Write-Host "4. Follow the installation wizard" -ForegroundColor Cyan
Write-Host "5. Restart PowerShell after installation" -ForegroundColor Cyan
Write-Host ""
Write-Host "After installation, verify with:" -ForegroundColor Yellow
Write-Host "  node --version" -ForegroundColor White
Write-Host "  npm --version" -ForegroundColor White
Write-Host ""
Write-Host "For detailed instructions, see: INSTALL_PREREQUISITES.md" -ForegroundColor Gray

