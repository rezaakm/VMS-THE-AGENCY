# Quick script to open download pages for Node.js and PostgreSQL

Write-Host "Opening download pages..." -ForegroundColor Cyan

# Open Node.js
Write-Host "Opening Node.js download page..." -ForegroundColor Yellow
Start-Process "https://nodejs.org/"

Start-Sleep -Seconds 2

# Open PostgreSQL  
Write-Host "Opening PostgreSQL download page..." -ForegroundColor Yellow
Start-Process "https://www.postgresql.org/download/windows/"

Write-Host ""
Write-Host "Download pages opened in your browser!" -ForegroundColor Green
Write-Host ""
Write-Host "Installation Instructions:" -ForegroundColor Yellow
Write-Host ""
Write-Host "NODE.JS:" -ForegroundColor Cyan
Write-Host "  1. Download the LTS version (v20.x.x)" -ForegroundColor White
Write-Host "  2. Run the .msi installer" -ForegroundColor White
Write-Host "  3. Follow the wizard (keep defaults)" -ForegroundColor White
Write-Host "  4. Restart PowerShell after installation" -ForegroundColor White
Write-Host ""
Write-Host "POSTGRESQL:" -ForegroundColor Cyan
Write-Host "  1. Click 'Download the installer'" -ForegroundColor White
Write-Host "  2. Download PostgreSQL 15 or 16" -ForegroundColor White
Write-Host "  3. Run the installer" -ForegroundColor White
Write-Host "  4. Set password (remember it!)" -ForegroundColor White
Write-Host "  5. Keep default port (5432)" -ForegroundColor White
Write-Host ""
Write-Host "After installation, verify with:" -ForegroundColor Yellow
Write-Host "  node --version" -ForegroundColor Gray
Write-Host "  psql --version" -ForegroundColor Gray

