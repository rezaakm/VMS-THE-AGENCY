# Setup and Testing Guide

## Prerequisites

Before running the VMS, you need to install:

1. **Node.js 18+** - Download from https://nodejs.org/
2. **PostgreSQL 14+** - Download from https://www.postgresql.org/download/
   - OR use Docker Desktop for Windows: https://www.docker.com/products/docker-desktop

## Quick Setup (Using Docker - Recommended)

### Step 1: Install Docker Desktop
Download and install Docker Desktop for Windows from: https://www.docker.com/products/docker-desktop

### Step 2: Start Services
```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
docker-compose up -d
```

### Step 3: Access the Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:3001
- API Docs: http://localhost:3001/api

---

## Manual Setup (Without Docker)

### Step 1: Install PostgreSQL

1. Download PostgreSQL from: https://www.postgresql.org/download/windows/
2. Install and note your password
3. Create a database:
   ```sql
   CREATE DATABASE vms_db;
   CREATE USER vms_user WITH PASSWORD 'vms_password';
   GRANT ALL PRIVILEGES ON DATABASE vms_db TO vms_user;
   ```

### Step 2: Install Node.js

1. Download Node.js 18+ from: https://nodejs.org/
2. Verify installation:
   ```powershell
   node --version
   npm --version
   ```

### Step 3: Setup Backend

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\backend

# Install dependencies
npm install

# Create .env file
copy .env.example .env

# Edit .env and update DATABASE_URL if needed:
# DATABASE_URL="postgresql://username:password@localhost:5432/vms_db"

# Generate Prisma Client
npm run prisma:generate

# Run database migrations
npm run prisma:migrate

# Seed database with sample data
npm run prisma:seed

# Start backend server
npm run start:dev
```

Backend will run on: http://localhost:3001

### Step 4: Setup Frontend (New Terminal)

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\frontend

# Install dependencies
npm install

# Create .env.local file
echo NEXT_PUBLIC_API_URL=http://localhost:3001 > .env.local

# Start frontend server
npm run dev
```

Frontend will run on: http://localhost:3000

---

## Testing the Application

### 1. Test Backend API

Open browser and visit:
- **API Health Check**: http://localhost:3001
- **API Documentation**: http://localhost:3001/api
- **API Info**: http://localhost:3001/info

### 2. Test Authentication

**Login Test:**
```bash
curl -X POST http://localhost:3001/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"admin@vms.com\",\"password\":\"admin123\"}"
```

Expected response:
```json
{
  "access_token": "eyJhbGc...",
  "user": {
    "id": "...",
    "email": "admin@vms.com",
    "firstName": "Admin",
    "lastName": "User",
    "role": "ADMIN"
  }
}
```

### 3. Test Frontend

1. Open browser: http://localhost:3000
2. You'll be redirected to login page
3. Login with:
   - Email: `admin@vms.com`
   - Password: `admin123`
4. You should see the dashboard with statistics

### 4. Test API Endpoints

With the access token from login, test endpoints:

**Get Vendors:**
```bash
curl http://localhost:3001/vendors \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

**Get Dashboard Stats:**
```bash
curl http://localhost:3001/reports/dashboard \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

**Get Purchase Orders:**
```bash
curl http://localhost:3001/purchase-orders \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### 5. Manual Testing Checklist

- [ ] Backend server starts without errors
- [ ] Frontend server starts without errors
- [ ] Database connection successful
- [ ] Can login with admin credentials
- [ ] Dashboard displays statistics
- [ ] Can view vendors list
- [ ] Can view purchase orders
- [ ] Can view contracts
- [ ] API documentation accessible
- [ ] All API endpoints return expected responses

---

## Troubleshooting

### Backend Issues

**Error: Cannot connect to database**
- Check PostgreSQL is running
- Verify DATABASE_URL in .env file
- Ensure database exists

**Error: Prisma Client not generated**
```powershell
npm run prisma:generate
```

**Error: Migration failed**
```powershell
npm run prisma:migrate reset
npm run prisma:seed
```

### Frontend Issues

**Error: Cannot connect to API**
- Check backend is running on port 3001
- Verify NEXT_PUBLIC_API_URL in .env.local
- Check CORS settings in backend

**Error: Module not found**
```powershell
npm install
```

### Port Already in Use

If ports 3000 or 3001 are in use:

**Backend:**
- Edit `packages/backend/.env` and change `PORT=3001` to another port
- Update frontend `.env.local` with new API URL

**Frontend:**
- Edit `packages/frontend/package.json` and change `"dev": "next dev -p 3000"` to another port

---

## Default Credentials

After seeding:
- **Admin**: admin@vms.com / admin123
- **Buyer**: buyer@vms.com / buyer123

⚠️ **Change these in production!**

---

## Running Tests

Once Node.js is installed:

```powershell
# Backend tests
cd packages/backend
npm test

# Frontend tests
cd packages/frontend
npm test
```

---

## Next Steps

1. Install Node.js and PostgreSQL (or Docker Desktop)
2. Follow the setup steps above
3. Run the application
4. Test all features
5. Customize as needed!

For issues, check the logs:
- Backend: Check terminal output
- Frontend: Check browser console (F12)
- Database: Check PostgreSQL logs

