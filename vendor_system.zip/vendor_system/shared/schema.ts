import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, date, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Vendors table
export const vendors = pgTable("vendors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // e.g., "Technology", "Marketing", "Logistics"
  status: text("status").notNull().default("active"), // "active", "inactive", "pending"
  email: text("email"),
  phone: text("phone"),
  website: text("website"),
  address: text("address"),
  contactPerson: text("contact_person"),
  rating: integer("rating").default(0), // 1-5 star rating
  notes: text("notes"),
});

// Contracts table
export const contracts = pgTable("contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vendorId: varchar("vendor_id").notNull(),
  name: text("name").notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  status: text("status").notNull().default("active"), // "active", "expired", "pending", "renewed"
  terms: text("terms"),
  renewalStatus: text("renewal_status"), // "auto-renew", "manual", "not-renewing"
});

// Contacts table
export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vendorId: varchar("vendor_id").notNull(),
  name: text("name").notNull(),
  title: text("title"),
  email: text("email").notNull(),
  phone: text("phone"),
  isPrimary: integer("is_primary").default(0), // boolean as integer
});

// Performance metrics table
export const performanceMetrics = pgTable("performance_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vendorId: varchar("vendor_id").notNull(),
  metricDate: date("metric_date").notNull(),
  deliveryScore: integer("delivery_score"), // 1-100
  qualityScore: integer("quality_score"), // 1-100
  responseTime: integer("response_time"), // in hours
  notes: text("notes"),
});

// Cost sheets table - stores job-level information from Excel files
export const costSheets = pgTable("cost_sheets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  jobNumber: text("job_number").notNull(),
  client: text("client").notNull(),
  event: text("event").notNull(),
  date: date("date"),
  driveFileId: text("drive_file_id").notNull().unique(), // Google Drive file ID
  fileName: text("file_name").notNull(),
  lastSynced: date("last_synced").notNull().default(sql`CURRENT_DATE`),
}, (table) => [
  index("IDX_cost_sheets_job_number").on(table.jobNumber),
  index("IDX_cost_sheets_client").on(table.client),
  index("IDX_cost_sheets_drive_file_id").on(table.driveFileId),
]);

// Cost sheet items table - stores individual line items from cost sheets
export const costSheetItems = pgTable("cost_sheet_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  costSheetId: varchar("cost_sheet_id").notNull().references(() => costSheets.id, { onDelete: "cascade" }),
  itemNumber: integer("item_number"),
  description: text("description").notNull(),
  vendor: text("vendor"),
  days: integer("days"), // quantity/days
  unitCost: decimal("unit_cost", { precision: 12, scale: 2 }),
  totalCost: decimal("total_cost", { precision: 12, scale: 2 }),
  unitSellingPrice: decimal("unit_selling_price", { precision: 12, scale: 2 }),
  totalSellingPrice: decimal("total_selling_price", { precision: 12, scale: 2 }),
}, (table) => [
  index("IDX_cost_sheet_items_cost_sheet_id").on(table.costSheetId),
  index("IDX_cost_sheet_items_vendor").on(table.vendor),
  index("IDX_cost_sheet_items_description").on(table.description),
]);

// Insert schemas
export const insertVendorSchema = createInsertSchema(vendors).omit({ id: true });
export const insertContractSchema = createInsertSchema(contracts).omit({ id: true });
export const insertContactSchema = createInsertSchema(contacts).omit({ id: true });
export const insertPerformanceMetricSchema = createInsertSchema(performanceMetrics).omit({ id: true });
export const insertCostSheetSchema = createInsertSchema(costSheets).omit({ id: true, lastSynced: true });
export const insertCostSheetItemSchema = createInsertSchema(costSheetItems).omit({ id: true });

// Types
export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = z.infer<typeof insertContractSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type PerformanceMetric = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetric = z.infer<typeof insertPerformanceMetricSchema>;

export type CostSheet = typeof costSheets.$inferSelect;
export type InsertCostSheet = z.infer<typeof insertCostSheetSchema>;

export type CostSheetItem = typeof costSheetItems.$inferSelect;
export type InsertCostSheetItem = z.infer<typeof insertCostSheetItemSchema>;
