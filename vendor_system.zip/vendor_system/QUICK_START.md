# 🚀 Quick Start Guide

## Option 1: Docker (Easiest - Recommended)

### Prerequisites
Install Docker Desktop: https://www.docker.com/products/docker-desktop

### Steps
```powershell
# 1. Navigate to project
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system

# 2. Start all services
docker-compose up -d

# 3. Wait for services to start (30-60 seconds)

# 4. Access the application
# Frontend: http://localhost:3000
# Backend: http://localhost:3001
# API Docs: http://localhost:3001/api

# 5. Login
# Email: admin@vms.com
# Password: admin123
```

---

## Option 2: Manual Setup

### Prerequisites
1. **Node.js 18+**: https://nodejs.org/
2. **PostgreSQL 14+**: https://www.postgresql.org/download/

### Steps

#### 1. Setup Database
```sql
CREATE DATABASE vms_db;
CREATE USER vms_user WITH PASSWORD 'vms_password';
GRANT ALL PRIVILEGES ON DATABASE vms_db TO vms_user;
```

#### 2. Setup Backend
```powershell
cd packages\backend
npm install
copy .env.example .env
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run start:dev
```

#### 3. Setup Frontend (New Terminal)
```powershell
cd packages\frontend
npm install
echo NEXT_PUBLIC_API_URL=http://localhost:3001 > .env.local
npm run dev
```

#### 4. Access Application
- Frontend: http://localhost:3000
- Backend: http://localhost:3001
- API Docs: http://localhost:3001/api

#### 5. Login
- Email: `admin@vms.com`
- Password: `admin123`

---

## Testing

Once the backend is running, test the API:

```powershell
# Run the test script
.\test-api.ps1
```

Or manually test:
1. Open http://localhost:3001/api in browser
2. Try the "GET /" endpoint
3. Try login endpoint: POST /auth/login

---

## Troubleshooting

**Port already in use?**
- Change PORT in `packages/backend/.env`
- Update `NEXT_PUBLIC_API_URL` in `packages/frontend/.env.local`

**Database connection error?**
- Check PostgreSQL is running
- Verify DATABASE_URL in `.env` file

**Module not found?**
- Run `npm install` in both backend and frontend directories

For detailed troubleshooting, see SETUP_AND_TEST.md

