# Verify installation and setup VMS

Write-Host "🔍 Verifying Installation..." -ForegroundColor Cyan
Write-Host ""

$allInstalled = $true

# Check Node.js
Write-Host "Checking Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ Node.js: $nodeVersion" -ForegroundColor Green
        $npmVersion = npm --version 2>&1
        Write-Host "  ✅ npm: $npmVersion" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Node.js: NOT FOUND" -ForegroundColor Red
        Write-Host "     Please restart PowerShell or install Node.js" -ForegroundColor Yellow
        $allInstalled = $false
    }
} catch {
    Write-Host "  ❌ Node.js: NOT FOUND" -ForegroundColor Red
    Write-Host "     Please restart PowerShell or install Node.js" -ForegroundColor Yellow
    $allInstalled = $false
}

Write-Host ""

# Check PostgreSQL
Write-Host "Checking PostgreSQL..." -ForegroundColor Yellow
try {
    $psqlVersion = psql --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ PostgreSQL: $psqlVersion" -ForegroundColor Green
    } else {
        Write-Host "  ❌ PostgreSQL: NOT FOUND" -ForegroundColor Red
        Write-Host "     Please restart PowerShell or add to PATH" -ForegroundColor Yellow
        $allInstalled = $false
    }
} catch {
    Write-Host "  ❌ PostgreSQL: NOT FOUND" -ForegroundColor Red
    Write-Host "     Please restart PowerShell or add to PATH: C:\Program Files\PostgreSQL\18\bin" -ForegroundColor Yellow
    $allInstalled = $false
}

Write-Host ""

if (-not $allInstalled) {
    Write-Host "⚠️  Some tools are not found in PATH." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "SOLUTION: Close and reopen PowerShell, then run this script again." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Or check installation:" -ForegroundColor Yellow
    Write-Host "  - Node.js: https://nodejs.org/" -ForegroundColor White
    Write-Host "  - PostgreSQL: C:\Program Files\PostgreSQL\18\bin" -ForegroundColor White
    exit 1
}

Write-Host "🎉 All prerequisites installed!" -ForegroundColor Green
Write-Host ""

# Setup database
Write-Host "🗄️  Setting up database..." -ForegroundColor Cyan
Write-Host ""
Write-Host "Would you like to setup the database now? (Y/N)" -ForegroundColor Yellow
$setupDb = Read-Host

if ($setupDb -eq "Y" -or $setupDb -eq "y") {
    Write-Host ""
    Write-Host "Running database setup..." -ForegroundColor Cyan
    $scriptPath = Join-Path $PSScriptRoot "setup-database.ps1"
    if (Test-Path $scriptPath) {
        & powershell -ExecutionPolicy Bypass -File $scriptPath
    } else {
        Write-Host "Database setup script not found. Creating database manually..." -ForegroundColor Yellow
        Write-Host "Run: psql -U postgres" -ForegroundColor White
        Write-Host "Then: CREATE DATABASE vms_db;" -ForegroundColor White
    }
}

Write-Host ""
Write-Host "🚀 Ready to setup VMS project!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. cd packages\backend" -ForegroundColor White
Write-Host "  2. npm install" -ForegroundColor White
Write-Host "  3. npm run prisma:generate" -ForegroundColor White
Write-Host "  4. npm run prisma:migrate" -ForegroundColor White
Write-Host "  5. npm run prisma:seed" -ForegroundColor White
Write-Host "  6. npm run start:dev" -ForegroundColor White
Write-Host ""
Write-Host "Would you like to setup the backend now? (Y/N)" -ForegroundColor Yellow
$setupBackend = Read-Host

if ($setupBackend -eq "Y" -or $setupBackend -eq "y") {
    Write-Host ""
    Write-Host "Setting up backend..." -ForegroundColor Cyan
    Set-Location (Join-Path $PSScriptRoot "packages\backend")
    
    Write-Host "Installing dependencies..." -ForegroundColor Yellow
    npm install
    
    if (Test-Path ".env.example") {
        if (-not (Test-Path ".env")) {
            Copy-Item ".env.example" ".env"
            Write-Host "✅ Created .env file" -ForegroundColor Green
        }
    }
    
    Write-Host "Generating Prisma Client..." -ForegroundColor Yellow
    npm run prisma:generate
    
    Write-Host "Running migrations..." -ForegroundColor Yellow
    npm run prisma:migrate
    
    Write-Host "Seeding database..." -ForegroundColor Yellow
    npm run prisma:seed
    
    Write-Host ""
    Write-Host "✅ Backend setup complete!" -ForegroundColor Green
    Write-Host ""
    Write-Host "To start the backend server:" -ForegroundColor Yellow
    Write-Host "  npm run start:dev" -ForegroundColor White
}

Write-Host ""

