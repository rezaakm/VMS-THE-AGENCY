# PowerShell script to setup PostgreSQL database for VMS

Write-Host "🗄️  PostgreSQL Database Setup for VMS" -ForegroundColor Cyan
Write-Host ""

# Check if PostgreSQL is installed
$psql = Get-Command psql -ErrorAction SilentlyContinue

if (-not $psql) {
    Write-Host "❌ PostgreSQL not found in PATH" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install PostgreSQL first:" -ForegroundColor Yellow
    Write-Host "  1. Visit: https://www.postgresql.org/download/windows/" -ForegroundColor Cyan
    Write-Host "  2. Download and install PostgreSQL 15 or 16" -ForegroundColor Cyan
    Write-Host "  3. Run this script again" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "For detailed instructions, see: INSTALL_PREREQUISITES.md" -ForegroundColor Gray
    exit 1
}

Write-Host "✅ PostgreSQL found: $(psql --version)" -ForegroundColor Green
Write-Host ""

# Database configuration
$dbName = "vms_db"
$dbUser = "vms_user"
$dbPassword = "vms_password"

Write-Host "Database Configuration:" -ForegroundColor Yellow
Write-Host "  Database Name: $dbName" -ForegroundColor Gray
Write-Host "  User: $dbUser" -ForegroundColor Gray
Write-Host "  Password: $dbPassword" -ForegroundColor Gray
Write-Host ""

Write-Host "⚠️  You will be prompted for the PostgreSQL 'postgres' user password" -ForegroundColor Yellow
Write-Host "   (This is the password you set during PostgreSQL installation)" -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "Continue with database setup? (Y/N)"

if ($confirm -ne "Y" -and $confirm -ne "y") {
    Write-Host "Setup cancelled." -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "Creating database and user..." -ForegroundColor Cyan

# SQL commands to execute
$sqlCommands = @"
-- Create database
CREATE DATABASE $dbName;

-- Create user
CREATE USER $dbUser WITH PASSWORD '$dbPassword';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE $dbName TO $dbUser;

-- Connect to vms_db and grant schema privileges
\c $dbName
GRANT ALL ON SCHEMA public TO $dbUser;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $dbUser;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $dbUser;
"@

# Save SQL to temporary file
$tempFile = [System.IO.Path]::GetTempFileName()
$sqlCommands | Out-File -FilePath $tempFile -Encoding utf8

try {
    # Execute SQL commands
    $env:PGPASSWORD = Read-Host "Enter PostgreSQL 'postgres' user password" -AsSecureString | ConvertFrom-SecureString -AsPlainText
    
    $result = & psql -U postgres -f $tempFile 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ Database setup completed successfully!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Database Configuration:" -ForegroundColor Yellow
        Write-Host "  Database: $dbName" -ForegroundColor Gray
        Write-Host "  User: $dbUser" -ForegroundColor Gray
        Write-Host "  Password: $dbPassword" -ForegroundColor Gray
        Write-Host ""
        Write-Host "Connection String:" -ForegroundColor Yellow
        Write-Host "  postgresql://$dbUser`:$dbPassword@localhost:5432/$dbName" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Next steps:" -ForegroundColor Yellow
        Write-Host "  1. Update packages/backend/.env with the connection string" -ForegroundColor White
        Write-Host "  2. Run: cd packages/backend && npm run prisma:migrate" -ForegroundColor White
        Write-Host "  3. Run: npm run prisma:seed" -ForegroundColor White
    } else {
        Write-Host ""
        Write-Host "❌ Database setup failed" -ForegroundColor Red
        Write-Host "Error output:" -ForegroundColor Yellow
        Write-Host $result -ForegroundColor Red
        Write-Host ""
        Write-Host "Common issues:" -ForegroundColor Yellow
        Write-Host "  - Wrong password for 'postgres' user" -ForegroundColor Gray
        Write-Host "  - Database already exists (that's okay, you can continue)" -ForegroundColor Gray
        Write-Host "  - PostgreSQL service not running" -ForegroundColor Gray
    }
} catch {
    Write-Host ""
    Write-Host "❌ Error: $_" -ForegroundColor Red
} finally {
    # Clean up temp file
    Remove-Item $tempFile -ErrorAction SilentlyContinue
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "For manual setup, run these commands in psql:" -ForegroundColor Gray
Write-Host "  psql -U postgres" -ForegroundColor White
Write-Host "  CREATE DATABASE $dbName;" -ForegroundColor White
Write-Host "  CREATE USER $dbUser WITH PASSWORD '$dbPassword';" -ForegroundColor White
Write-Host "  GRANT ALL PRIVILEGES ON DATABASE $dbName TO $dbUser;" -ForegroundColor White
Write-Host "  \q" -ForegroundColor White

