# Vendor Management System (VMS)

A comprehensive, modern vendor management system built with NestJS, Next.js, Prisma, and PostgreSQL.

## 🚀 Features

### Vendor Management
- **Vendor Registration & Onboarding** - Complete vendor profile management
- **Category Management** - Organize vendors by categories and industries
- **Document Management** - Upload and manage vendor certificates, licenses, and documents
- **Vendor Status Tracking** - Active, inactive, pending approval, blacklisted

### Purchase Order Management
- **PO Creation & Tracking** - Create and manage purchase orders
- **Order Status Workflow** - Draft, submitted, approved, completed, cancelled
- **Line Items Management** - Multiple items per order with pricing
- **Order History** - Complete audit trail of all orders

### Contract Management
- **Contract Creation** - Define terms, dates, and conditions
- **Contract Renewal Tracking** - Automated expiry notifications
- **Contract Templates** - Reusable contract templates
- **Digital Signatures** - Integration ready for e-signatures

### Vendor Performance
- **Performance Evaluations** - Rate vendors on quality, delivery, pricing
- **Automated Scoring** - Calculate vendor performance scores
- **Performance Reports** - Detailed analytics and reporting
- **Vendor Comparison** - Compare vendors side-by-side

### Financial Management
- **Invoice Tracking** - Link invoices to purchase orders
- **Payment History** - Track all vendor payments
- **Credit Terms Management** - Define payment terms per vendor
- **Spend Analytics** - Analyze spending patterns

### Reporting & Analytics
- **Dashboard** - Real-time metrics and KPIs
- **Custom Reports** - Generate reports by various criteria
- **Export Functionality** - Export data to CSV, Excel, PDF
- **Data Visualization** - Charts and graphs for insights

### User Management
- **Role-Based Access Control** - Admin, Manager, Buyer, Viewer roles
- **Authentication & Authorization** - Secure JWT-based auth
- **Audit Logs** - Track all user actions
- **Multi-tenant Support** - Ready for SaaS deployment

## 🛠 Tech Stack

### Backend
- **NestJS** - Progressive Node.js framework
- **Prisma** - Next-generation ORM
- **PostgreSQL** - Robust relational database
- **JWT** - Secure authentication
- **Swagger** - API documentation
- **Class Validator** - Request validation

### Frontend
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first CSS
- **shadcn/ui** - Beautiful UI components
- **React Query** - Data fetching and caching
- **React Hook Form** - Form management
- **Recharts** - Data visualization

### DevOps
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **GitHub Actions** - CI/CD (optional)

## 📋 Prerequisites

- Node.js 18+ 
- PostgreSQL 14+
- Docker & Docker Compose (optional)
- npm or yarn

## 🚀 Quick Start

### Using Docker (Recommended)

```bash
# Clone the repository
git clone https://github.com/rezaakm/vendor-management-system.git
cd vendor-management-system

# Start all services
docker-compose up -d

# The application will be available at:
# Frontend: http://localhost:3000
# Backend: http://localhost:3001
# API Docs: http://localhost:3001/api
```

### Manual Setup

#### 1. Install Dependencies

```bash
npm install
```

#### 2. Setup Database

```bash
# Create PostgreSQL database
createdb vms_db

# Copy environment file
cp packages/backend/.env.example packages/backend/.env

# Update database connection in packages/backend/.env
DATABASE_URL="postgresql://username:password@localhost:5432/vms_db"
```

#### 3. Run Migrations

```bash
npm run prisma:migrate
```

#### 4. Start Development Servers

```bash
# Terminal 1 - Backend
npm run dev:backend

# Terminal 2 - Frontend
npm run dev:frontend
```

The application will be available at:
- Frontend: http://localhost:3000
- Backend: http://localhost:3001
- API Documentation: http://localhost:3001/api

## 📁 Project Structure

```
vendor-management-system/
├── packages/
│   ├── backend/              # NestJS backend API
│   │   ├── src/
│   │   │   ├── auth/        # Authentication module
│   │   │   ├── vendors/     # Vendor management
│   │   │   ├── purchase-orders/  # PO management
│   │   │   ├── contracts/   # Contract management
│   │   │   ├── evaluations/ # Performance evaluations
│   │   │   ├── reports/     # Reporting module
│   │   │   └── users/       # User management
│   │   ├── prisma/          # Database schema & migrations
│   │   └── test/            # Tests
│   │
│   └── frontend/            # Next.js frontend
│       ├── src/
│       │   ├── app/         # App router pages
│       │   ├── components/  # React components
│       │   ├── lib/         # Utilities
│       │   └── hooks/       # Custom hooks
│       └── public/          # Static assets
│
├── docker-compose.yml       # Docker orchestration
└── README.md               # This file
```

## 🔐 Default Credentials

After running migrations, use these credentials to login:

- **Email:** admin@vms.com
- **Password:** admin123

⚠️ **Important:** Change these credentials immediately in production!

## 📚 API Documentation

Once the backend is running, visit http://localhost:3001/api for interactive Swagger documentation.

### Key Endpoints

#### Authentication
- `POST /auth/login` - User login
- `POST /auth/register` - Register new user
- `POST /auth/refresh` - Refresh token

#### Vendors
- `GET /vendors` - List all vendors
- `POST /vendors` - Create vendor
- `GET /vendors/:id` - Get vendor details
- `PUT /vendors/:id` - Update vendor
- `DELETE /vendors/:id` - Delete vendor

#### Purchase Orders
- `GET /purchase-orders` - List all POs
- `POST /purchase-orders` - Create PO
- `GET /purchase-orders/:id` - Get PO details
- `PUT /purchase-orders/:id` - Update PO
- `PATCH /purchase-orders/:id/status` - Update PO status

#### Contracts
- `GET /contracts` - List all contracts
- `POST /contracts` - Create contract
- `GET /contracts/:id` - Get contract details
- `GET /contracts/expiring` - Get expiring contracts

#### Evaluations
- `POST /evaluations` - Create vendor evaluation
- `GET /evaluations/vendor/:vendorId` - Get vendor evaluations
- `GET /evaluations/scores/:vendorId` - Get vendor score

## 🧪 Testing

```bash
# Backend tests
npm run test --workspace=packages/backend

# Frontend tests
npm run test --workspace=packages/frontend

# E2E tests
npm run test:e2e
```

## 🚢 Deployment

### Environment Variables

#### Backend (.env)
```env
DATABASE_URL="postgresql://user:password@localhost:5432/vms_db"
JWT_SECRET="your-secret-key"
JWT_EXPIRATION="7d"
PORT=3001
NODE_ENV=production
```

#### Frontend (.env.local)
```env
NEXT_PUBLIC_API_URL="http://localhost:3001"
```

### Docker Production Build

```bash
docker-compose -f docker-compose.prod.yml up -d
```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**rezaakm**
- GitHub: [@rezaakm](https://github.com/rezaakm)

## 🙏 Acknowledgments

- NestJS for the amazing backend framework
- Next.js team for the incredible React framework
- Prisma for the modern ORM
- shadcn/ui for beautiful components

## 📞 Support

For support, email support@vms.com or open an issue in the GitHub repository.

---

Made with ❤️ by rezaakm

