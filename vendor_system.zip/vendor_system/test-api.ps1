# PowerShell script to test VMS API endpoints

$baseUrl = "http://localhost:3001"
$email = "admin@vms.com"
$password = "admin123"

Write-Host "🧪 Testing Vendor Management System API" -ForegroundColor Cyan
Write-Host ""

# Test 1: Health Check
Write-Host "1️⃣ Testing Health Check..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl" -Method Get
    Write-Host "✅ Health Check: OK" -ForegroundColor Green
    Write-Host "   Status: $($response.status)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Health Check Failed: $_" -ForegroundColor Red
    exit 1
}

# Test 2: Login
Write-Host ""
Write-Host "2️⃣ Testing Login..." -ForegroundColor Yellow
try {
    $loginBody = @{
        email = $email
        password = $password
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method Post -Body $loginBody -ContentType "application/json"
    $token = $response.access_token
    Write-Host "✅ Login: Success" -ForegroundColor Green
    Write-Host "   User: $($response.user.email)" -ForegroundColor Gray
    Write-Host "   Role: $($response.user.role)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Login Failed: $_" -ForegroundColor Red
    exit 1
}

# Test 3: Get Dashboard Stats
Write-Host ""
Write-Host "3️⃣ Testing Dashboard Stats..." -ForegroundColor Yellow
try {
    $headers = @{
        "Authorization" = "Bearer $token"
    }
    $response = Invoke-RestMethod -Uri "$baseUrl/reports/dashboard" -Method Get -Headers $headers
    Write-Host "✅ Dashboard Stats: OK" -ForegroundColor Green
    Write-Host "   Vendors: $($response.vendors.total) (Active: $($response.vendors.active))" -ForegroundColor Gray
    Write-Host "   Purchase Orders: $($response.purchaseOrders.total)" -ForegroundColor Gray
    Write-Host "   Contracts: $($response.contracts.total)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard Stats Failed: $_" -ForegroundColor Red
}

# Test 4: Get Vendors
Write-Host ""
Write-Host "4️⃣ Testing Get Vendors..." -ForegroundColor Yellow
try {
    $headers = @{
        "Authorization" = "Bearer $token"
    }
    $response = Invoke-RestMethod -Uri "$baseUrl/vendors" -Method Get -Headers $headers
    Write-Host "✅ Get Vendors: OK" -ForegroundColor Green
    Write-Host "   Found $($response.Count) vendors" -ForegroundColor Gray
} catch {
    Write-Host "❌ Get Vendors Failed: $_" -ForegroundColor Red
}

# Test 5: Get Purchase Orders
Write-Host ""
Write-Host "5️⃣ Testing Get Purchase Orders..." -ForegroundColor Yellow
try {
    $headers = @{
        "Authorization" = "Bearer $token"
    }
    $response = Invoke-RestMethod -Uri "$baseUrl/purchase-orders" -Method Get -Headers $headers
    Write-Host "✅ Get Purchase Orders: OK" -ForegroundColor Green
    Write-Host "   Found $($response.Count) purchase orders" -ForegroundColor Gray
} catch {
    Write-Host "❌ Get Purchase Orders Failed: $_" -ForegroundColor Red
}

# Test 6: Get Contracts
Write-Host ""
Write-Host "6️⃣ Testing Get Contracts..." -ForegroundColor Yellow
try {
    $headers = @{
        "Authorization" = "Bearer $token"
    }
    $response = Invoke-RestMethod -Uri "$baseUrl/contracts" -Method Get -Headers $headers
    Write-Host "✅ Get Contracts: OK" -ForegroundColor Green
    Write-Host "   Found $($response.Count) contracts" -ForegroundColor Gray
} catch {
    Write-Host "❌ Get Contracts Failed: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "🎉 API Testing Complete!" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  - Open Frontend: http://localhost:3000" -ForegroundColor White
Write-Host "  - View API Docs: http://localhost:3001/api" -ForegroundColor White

