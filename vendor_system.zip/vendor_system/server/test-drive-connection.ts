// Quick test script to verify Google Drive connectivity
import { getUncachableGoogleDriveClient, listExcelFilesInFolder } from './drive-service';

const FOLDER_ID = '1SY44mewvsstdD4NQgpiSU6J4bTTNCXTT'; // CallSheets folder

async function testDriveConnection() {
  console.log('🔍 Testing Google Drive connectivity...');
  console.log(`📁 Folder ID: ${FOLDER_ID}`);
  
  try {
    // Test 1: Get Drive client
    console.log('\n1. Getting Google Drive client...');
    const drive = await getUncachableGoogleDriveClient();
    console.log('✅ Successfully authenticated with Google Drive');

    // Test 2: Get folder metadata
    console.log('\n2. Fetching folder metadata...');
    const folderResponse = await drive.files.get({
      fileId: FOLDER_ID,
      fields: 'id, name, mimeType, capabilities',
    });
    
    console.log('✅ Folder found:');
    console.log(`   Name: ${folderResponse.data.name}`);
    console.log(`   ID: ${folderResponse.data.id}`);
    console.log(`   Type: ${folderResponse.data.mimeType}`);

    // Test 3: List Excel files in the folder
    console.log('\n3. Listing Excel files in folder...');
    const files = await listExcelFilesInFolder(FOLDER_ID);
    
    console.log(`✅ Found ${files.length} Excel files`);
    
    if (files.length > 0) {
      console.log('\n📄 Sample files (first 5):');
      files.slice(0, 5).forEach((file, index) => {
        console.log(`   ${index + 1}. ${file.name}`);
        console.log(`      - Modified: ${new Date(file.modifiedTime).toLocaleDateString()}`);
      });
    }

    console.log('\n✅ Google Drive connectivity test PASSED');
    console.log(`📊 Summary: ${files.length} Excel files accessible in CallSheets folder`);
    
    return {
      success: true,
      folderName: folderResponse.data.name,
      fileCount: files.length,
    };
  } catch (error: any) {
    console.error('\n❌ Google Drive connectivity test FAILED');
    console.error(`Error: ${error.message}`);
    
    if (error.message.includes('not connected')) {
      console.error('\n💡 Action required: Connect Google Drive in Replit integrations');
    } else if (error.response?.status === 404) {
      console.error('\n💡 Folder not found. Please verify the folder ID is correct.');
    } else if (error.response?.status === 403) {
      console.error('\n💡 Permission denied. The connected Google account needs access to this folder.');
    }
    
    return {
      success: false,
      error: error.message,
    };
  }
}

// Run the test
testDriveConnection()
  .then((result) => {
    process.exit(result.success ? 0 : 1);
  })
  .catch((error) => {
    console.error('Unexpected error:', error);
    process.exit(1);
  });
