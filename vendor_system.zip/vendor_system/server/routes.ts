import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertVendorSchema,
  insertContractSchema,
  insertContactSchema,
  insertPerformanceMetricSchema,
  costSheets,
  costSheetItems,
} from "@shared/schema";
import { parseNaturalLanguageQuery, normalizeItem, extractEstimate } from "./ai-service";
import { syncCostSheets } from "./sync-service";
import { parseExcelFile } from "./excel-parser";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { db } from "./db";
import { eq, and, like, gte, lte, or, ilike, sql } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware (Referenced from Replit Auth blueprint)
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Vendors (protected routes)
  app.get("/api/vendors", isAuthenticated, async (_req, res) => {
    try {
      const vendors = await storage.getVendors();
      res.json(vendors);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vendors" });
    }
  });

  app.get("/api/vendors/:id", isAuthenticated, async (req, res) => {
    try {
      const vendor = await storage.getVendor(req.params.id);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json(vendor);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vendor" });
    }
  });

  app.post("/api/vendors", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertVendorSchema.parse(req.body);
      const vendor = await storage.createVendor(validatedData);
      res.status(201).json(vendor);
    } catch (error) {
      res.status(400).json({ error: "Invalid vendor data" });
    }
  });

  app.patch("/api/vendors/:id", isAuthenticated, async (req, res) => {
    try {
      const updates = insertVendorSchema.partial().parse(req.body);
      const vendor = await storage.updateVendor(req.params.id, updates);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json(vendor);
    } catch (error) {
      res.status(400).json({ error: "Invalid vendor data" });
    }
  });

  app.delete("/api/vendors/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deleteVendor(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vendor" });
    }
  });


  // Contracts (protected routes)
  app.get("/api/contracts", isAuthenticated, async (_req, res) => {
    try {
      const contracts = await storage.getContracts();
      res.json(contracts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contracts" });
    }
  });

  app.get("/api/contracts/:id", isAuthenticated, async (req, res) => {
    try {
      const contract = await storage.getContract(req.params.id);
      if (!contract) {
        return res.status(404).json({ error: "Contract not found" });
      }
      res.json(contract);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contract" });
    }
  });

  app.post("/api/contracts", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(validatedData);
      res.status(201).json(contract);
    } catch (error) {
      res.status(400).json({ error: "Invalid contract data" });
    }
  });

  app.patch("/api/contracts/:id", isAuthenticated, async (req, res) => {
    try {
      const updates = insertContractSchema.partial().parse(req.body);
      const contract = await storage.updateContract(req.params.id, updates);
      if (!contract) {
        return res.status(404).json({ error: "Contract not found" });
      }
      res.json(contract);
    } catch (error) {
      res.status(400).json({ error: "Invalid contract data" });
    }
  });

  app.delete("/api/contracts/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deleteContract(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Contract not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete contract" });
    }
  });

  // Contacts (protected routes)
  app.get("/api/contacts", isAuthenticated, async (_req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  app.get("/api/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const contact = await storage.getContact(req.params.id);
      if (!contact) {
        return res.status(404).json({ error: "Contact not found" });
      }
      res.json(contact);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contact" });
    }
  });

  app.post("/api/contacts", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.status(201).json(contact);
    } catch (error) {
      res.status(400).json({ error: "Invalid contact data" });
    }
  });

  app.patch("/api/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const updates = insertContactSchema.partial().parse(req.body);
      const contact = await storage.updateContact(req.params.id, updates);
      if (!contact) {
        return res.status(404).json({ error: "Contact not found" });
      }
      res.json(contact);
    } catch (error) {
      res.status(400).json({ error: "Invalid contact data" });
    }
  });

  app.delete("/api/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deleteContact(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Contact not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete contact" });
    }
  });

  // Performance Metrics
  app.get("/api/performance", isAuthenticated, async (_req, res) => {
    try {
      const metrics = await storage.getPerformanceMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch performance metrics" });
    }
  });

  app.get("/api/performance/:id", isAuthenticated, async (req, res) => {
    try {
      const metric = await storage.getPerformanceMetric(req.params.id);
      if (!metric) {
        return res.status(404).json({ error: "Performance metric not found" });
      }
      res.json(metric);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch performance metric" });
    }
  });

  app.post("/api/performance", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertPerformanceMetricSchema.parse(req.body);
      const metric = await storage.createPerformanceMetric(validatedData);
      res.status(201).json(metric);
    } catch (error) {
      res.status(400).json({ error: "Invalid performance metric data" });
    }
  });

  app.patch("/api/performance/:id", isAuthenticated, async (req, res) => {
    try {
      const updates = insertPerformanceMetricSchema.partial().parse(req.body);
      const metric = await storage.updatePerformanceMetric(req.params.id, updates);
      if (!metric) {
        return res.status(404).json({ error: "Performance metric not found" });
      }
      res.json(metric);
    } catch (error) {
      res.status(400).json({ error: "Invalid performance metric data" });
    }
  });

  app.delete("/api/performance/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deletePerformanceMetric(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Performance metric not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete performance metric" });
    }
  });

  // AI Integration Routes
  app.post("/api/ai/parse-query", isAuthenticated, async (req, res) => {
    try {
      const { query } = req.body;
      if (!query || typeof query !== "string") {
        return res.status(400).json({ error: "Query is required" });
      }
      const parsed = await parseNaturalLanguageQuery(query);
      res.json(parsed);
    } catch (error) {
      console.error("Error in /api/ai/parse-query:", error);
      res.status(500).json({ error: "Failed to parse query" });
    }
  });

  app.post("/api/ai/normalize", isAuthenticated, async (req, res) => {
    try {
      const { item, vendor, price } = req.body;
      if (!item || typeof item !== "string") {
        return res.status(400).json({ error: "Item is required" });
      }
      const normalized = await normalizeItem(item, vendor, price);
      res.json(normalized);
    } catch (error) {
      console.error("Error in /api/ai/normalize:", error);
      res.status(500).json({ error: "Failed to normalize item" });
    }
  });

  app.post("/api/ai/extract-estimate", isAuthenticated, async (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "Text is required" });
      }
      const items = await extractEstimate(text);
      res.json(items);
    } catch (error) {
      console.error("Error in /api/ai/extract-estimate:", error);
      res.status(500).json({ error: "Failed to extract estimate" });
    }
  });

  // Cost Sheets (using database instead of storage)
  app.get("/api/cost-sheets", isAuthenticated, async (_req, res) => {
    try {
      const sheets = await db.select().from(costSheets);
      res.json(sheets);
    } catch (error) {
      console.error("Error fetching cost sheets:", error);
      res.status(500).json({ error: "Failed to fetch cost sheets" });
    }
  });

  app.get("/api/cost-sheets/:id", isAuthenticated, async (req, res) => {
    try {
      const [sheet] = await db.select().from(costSheets).where(eq(costSheets.id, req.params.id));
      if (!sheet) {
        return res.status(404).json({ error: "Cost sheet not found" });
      }
      res.json(sheet);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cost sheet" });
    }
  });

  app.get("/api/cost-sheet-items", isAuthenticated, async (_req, res) => {
    try {
      const items = await db.select().from(costSheetItems);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cost sheet items" });
    }
  });

  // Upload and parse Excel cost sheet
  app.post("/api/cost-sheets/upload", isAuthenticated, async (req, res) => {
    try {
      const { fileName, fileData } = req.body;
      
      if (!fileName || !fileData) {
        return res.status(400).json({ error: "fileName and fileData are required" });
      }

      // Decode base64 file data
      const buffer = Buffer.from(fileData, 'base64');
      
      // Parse the Excel file directly from buffer
      const parsedData = parseExcelFile(buffer, fileName);
      
      if (!parsedData) {
        throw new Error("Failed to parse Excel file");
      }

      // Create cost sheet
      const costSheet = await storage.createCostSheet({
        ...parsedData.costSheet,
        driveFileId: `upload_${Date.now()}`, // Generate unique ID for uploaded files
        fileName: fileName,
      });

      // Create cost sheet items
      let itemsCreated = 0;
      for (const itemData of parsedData.items) {
        await storage.createCostSheetItem({
          ...itemData,
          costSheetId: costSheet.id,
        });
        itemsCreated++;
      }

      res.json({
        success: true,
        costSheet,
        itemsCreated,
      });
    } catch (error) {
      console.error("Error uploading cost sheet:", error);
      res.status(500).json({ 
        error: "Failed to upload and parse cost sheet",
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Sync cost sheets from Google Drive
  app.post("/api/cost-sheets/sync", isAuthenticated, async (req, res) => {
    try {
      const { syncCostSheets } = await import('./sync-service');
      // Use the user's specific folder ID
      const result = await syncCostSheets('1SY44mewvsstdD4NQgpiSU6J4bTTNCXTT');
      res.json(result);
    } catch (error) {
      console.error("Error syncing cost sheets:", error);
      res.status(500).json({ 
        success: false,
        filesProcessed: 0,
        itemsCreated: 0,
        errors: [error instanceof Error ? error.message : String(error)]
      });
    }
  });

  // Delete single cost sheet item
  app.delete("/api/cost-sheet-items/:id", isAuthenticated, async (req, res) => {
    try {
      const result = await db.delete(costSheetItems).where(eq(costSheetItems.id, req.params.id));
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting cost sheet item:", error);
      res.status(500).json({ error: "Failed to delete cost sheet item" });
    }
  });

  // Bulk delete cost sheet items
  app.post("/api/cost-sheet-items/bulk-delete", isAuthenticated, async (req, res) => {
    try {
      const { ids } = req.body;
      if (!Array.isArray(ids)) {
        return res.status(400).json({ error: "ids must be an array" });
      }
      
      // Delete all items with matching IDs
      for (const id of ids) {
        await db.delete(costSheetItems).where(eq(costSheetItems.id, id));
      }
      
      res.json({ deleted: ids.length });
    } catch (error) {
      console.error("Error bulk deleting cost sheet items:", error);
      res.status(500).json({ error: "Failed to delete cost sheet items" });
    }
  });

  app.get("/api/cost-sheet-items/search", isAuthenticated, async (req, res) => {
    try {
      const { q, vendor, minPrice, maxPrice, jobNumber, client } = req.query;
      if (!q || typeof q !== "string") {
        return res.status(400).json({ error: "Search query 'q' is required" });
      }

      // Build search conditions
      const conditions = [];
      
      // Search in description (case-insensitive)
      conditions.push(ilike(costSheetItems.description, `%${q}%`));
      
      // Apply filters
      if (vendor && typeof vendor === "string") {
        conditions.push(ilike(costSheetItems.vendor, `%${vendor}%`));
      }
      if (minPrice && typeof minPrice === "string") {
        const min = parseFloat(minPrice);
        if (!isNaN(min)) {
          conditions.push(gte(sql`CAST(${costSheetItems.unitCost} AS DECIMAL)`, min.toString()));
        }
      }
      if (maxPrice && typeof maxPrice === "string") {
        const max = parseFloat(maxPrice);
        if (!isNaN(max)) {
          conditions.push(lte(sql`CAST(${costSheetItems.unitCost} AS DECIMAL)`, max.toString()));
        }
      }

      // Search items
      const items = await db
        .select()
        .from(costSheetItems)
        .where(and(...conditions))
        .limit(100);
      
      // Filter by jobNumber or client if specified (join with cost sheets)
      let enrichedItems = await Promise.all(
        items.map(async (item) => {
          const [sheet] = await db
            .select()
            .from(costSheets)
            .where(eq(costSheets.id, item.costSheetId));
          return {
            ...item,
            costSheet: sheet,
          };
        })
      );

      // Apply cost sheet filters
      if (jobNumber && typeof jobNumber === "string") {
        enrichedItems = enrichedItems.filter(
          (item) => item.costSheet?.jobNumber?.toLowerCase().includes(jobNumber.toLowerCase())
        );
      }
      if (client && typeof client === "string") {
        enrichedItems = enrichedItems.filter(
          (item) => item.costSheet?.client?.toLowerCase().includes(client.toLowerCase())
        );
      }
      
      res.json(enrichedItems);
    } catch (error) {
      console.error("Error searching cost sheet items:", error);
      res.status(500).json({ error: "Failed to search cost sheet items" });
    }
  });

  // Vendor comparison endpoint
  app.get("/api/compare-vendors", isAuthenticated, async (req, res) => {
    try {
      const { v1, v2 } = req.query as { v1: string; v2: string };
      if (!v1 || !v2) {
        return res.status(400).json({ error: "Two vendors required (v1 and v2 query params)" });
      }

      const getStats = async (vendorName: string) => {
        // Get cost sheet statistics for this vendor
        const costStats = await db
          .select({
            avgUnitCost: sql<number>`COALESCE(AVG(CAST(${costSheetItems.unitCost} AS DECIMAL)), 0)`,
            avgTotalCost: sql<number>`COALESCE(AVG(CAST(${costSheetItems.totalCost} AS DECIMAL)), 0)`,
            totalJobs: sql<number>`COUNT(DISTINCT ${costSheetItems.costSheetId})`,
          })
          .from(costSheetItems)
          .where(ilike(costSheetItems.vendor, `%${vendorName}%`));

        // Get vendor information (if exists)
        const vendorInfo = await db
          .select({
            rating: sql<number>`COALESCE(${sql`vendors.rating`}, 0)`,
          })
          .from(sql`vendors`)
          .where(ilike(sql`vendors.name`, `%${vendorName}%`))
          .limit(1);

        // Get performance metrics (if any)
        const perfMetrics = await db
          .select({
            avgLeadTime: sql<number>`COALESCE(AVG(${sql`performance_metrics.response_time`}), 0)`,
          })
          .from(sql`performance_metrics`)
          .innerJoin(sql`vendors`, eq(sql`vendors.id`, sql`performance_metrics.vendor_id`))
          .where(ilike(sql`vendors.name`, `%${vendorName}%`))
          .limit(1);

        // Get recent items
        const recentItems = await db
          .select({
            description: costSheetItems.description,
            totalCost: costSheetItems.totalCost,
            costSheetId: costSheetItems.costSheetId,
          })
          .from(costSheetItems)
          .where(ilike(costSheetItems.vendor, `%${vendorName}%`))
          .orderBy(sql`${costSheetItems.id} DESC`)
          .limit(5);

        // Enrich with dates
        const enrichedRecentItems = await Promise.all(
          recentItems.map(async (item) => {
            const [sheet] = await db
              .select({ date: costSheets.date })
              .from(costSheets)
              .where(eq(costSheets.id, item.costSheetId));
            return {
              description: item.description || '',
              totalCost: Number(item.totalCost) || 0,
              date: sheet?.date || 'Recent',
            };
          })
        );

        return {
          vendor: vendorName,
          avgUnitCost: Number(costStats[0]?.avgUnitCost) || 0,
          avgTotalCost: Number(costStats[0]?.avgTotalCost) || 0,
          avgLeadTime: Number(perfMetrics[0]?.avgLeadTime) || 0,
          totalJobs: Number(costStats[0]?.totalJobs) || 0,
          rating: Number(vendorInfo[0]?.rating) || 0,
          recentItems: enrichedRecentItems,
        };
      };

      const [v1Stats, v2Stats] = await Promise.all([getStats(v1), getStats(v2)]);
      res.json({ v1: v1Stats, v2: v2Stats });
    } catch (error) {
      console.error("Error comparing vendors:", error);
      res.status(500).json({ error: "Failed to compare vendors" });
    }
  });

  // AI Assistant for vendor comparison
  app.post("/api/vendor-ai", isAuthenticated, async (req, res) => {
    try {
      const { question, vendor1, vendor2 } = req.body;
      
      if (!question || typeof question !== "string") {
        return res.status(400).json({ error: "Question is required" });
      }

      // Use the existing OpenAI integration (Replit AI integration)
      const OpenAI = (await import("openai")).default;
      const openai = new OpenAI({
        baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
        apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
      });

      const prompt = `You are a vendor comparison assistant for a vendor management system. 
The user is comparing two vendors: "${vendor1}" and "${vendor2}".
The system contains 2,977 cost sheet items from 467 jobs with pricing data for various vendors.

User question: ${question}

Provide a helpful, concise answer (2-3 sentences) based on typical vendor comparison scenarios:
- Pricing comparisons
- Lead time/speed comparisons
- Quality and reliability
- Specific product categories (lighting, backdrops, etc.)

If you don't have specific data, provide general guidance based on the question.`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a helpful vendor comparison assistant. Keep responses brief and actionable." },
          { role: "user", content: prompt }
        ],
        max_tokens: 150,
      });

      const answer = completion.choices[0]?.message?.content || "I couldn't generate an answer. Please try rephrasing your question.";
      
      res.json({ answer });
    } catch (error: any) {
      console.error("Error with vendor AI:", error);
      res.status(500).json({ error: "Failed to process AI request", details: error.message });
    }
  });

  // Vendor cost trend analysis
  app.get("/api/vendor-trend", isAuthenticated, async (req, res) => {
    try {
      const { v1, v2 } = req.query as { v1: string; v2: string };

      const getMonthlyData = async (vendor: string) => {
        const raw = await db
          .select({
            month: sql<string>`TO_CHAR(${costSheets.date}, 'YYYY-MM')`,
            totalCost: sql<number>`COALESCE(SUM(CAST(${costSheetItems.totalCost} AS DECIMAL)), 0)`,
          })
          .from(costSheetItems)
          .innerJoin(costSheets, eq(costSheetItems.costSheetId, costSheets.id))
          .where(vendor !== "none" ? ilike(costSheetItems.vendor, `%${vendor}%`) : sql`1=1`)
          .groupBy(sql`TO_CHAR(${costSheets.date}, 'YYYY-MM')`)
          .orderBy(sql`TO_CHAR(${costSheets.date}, 'YYYY-MM')`);

        return raw.map((r) => ({
          month: r.month,
          cost: Number(r.totalCost) || 0,
          vendor,
        }));
      };

      const [data1, data2] = await Promise.all([
        v1 && v1 !== "none" ? getMonthlyData(v1) : Promise.resolve([]),
        v2 && v2 !== "none" ? getMonthlyData(v2) : Promise.resolve([]),
      ]);

      // Merge data for chart
      const allMonths = Array.from(
        new Set([...data1.map((d) => d.month), ...data2.map((d) => d.month)])
      ).sort();

      const merged = allMonths.map((month) => {
        const v1Entry = data1.find((d) => d.month === month);
        const v2Entry = data2.find((d) => d.month === month);
        return {
          month,
          cost: v1Entry?.cost || v2Entry?.cost || 0,
          vendor: v1Entry?.vendor || v2Entry?.vendor || "",
        };
      });

      // Calculate trend % (current vs previous month)
      const calcTrend = (vendorData: typeof data1) => {
        if (vendorData.length < 2) return 0;
        const current = vendorData[vendorData.length - 1].cost;
        const previous = vendorData[vendorData.length - 2].cost;
        return previous === 0 ? 0 : ((current - previous) / previous) * 100;
      };

      res.json({
        data: merged,
        trend: {
          v1: v1 && v1 !== "none" ? calcTrend(data1) : 0,
          v2: v2 && v2 !== "none" ? calcTrend(data2) : 0,
        },
      });
    } catch (error) {
      console.error("Error fetching vendor trend:", error);
      res.status(500).json({ error: "Failed to fetch vendor trend data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
