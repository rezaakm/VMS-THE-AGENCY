import * as XLSX from 'xlsx';
import { db } from './db';
import { costSheets, costSheetItems, type InsertCostSheet, type InsertCostSheetItem } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface ParsedCostSheet {
  costSheet: Omit<InsertCostSheet, 'driveFileId' | 'fileName'>;
  items: Omit<InsertCostSheetItem, 'costSheetId'>[];
}

/**
 * Parse job metadata from filename
 */
function parseFilenameMetadata(fileName: string): { jobNumber: string; client: string; event: string } {
  const withoutExt = fileName.replace(/\.xlsx?$/i, '');
  const parts = withoutExt.split(/[-–—]/);
  
  const jobNumber = parts[0]?.trim() || 'Unknown';
  const client = parts[1]?.trim() || 'Unknown Client';
  const event = parts.slice(2).join(' - ').trim() || 'Cost Sheet';
  
  return { jobNumber, client, event };
}

/**
 * Parse Excel file and insert into database
 * Handles the specific format with header rows and column-based data
 */
export async function parseAndInsertExcelFile(
  fileBuffer: Buffer,
  fileName: string,
  driveFileId: string
): Promise<{ success: boolean; rowsInserted: number; rowsSkipped: number; error?: string }> {
  let rowsInserted = 0;
  let rowsSkipped = 0;

  try {
    const { jobNumber, client, event } = parseFilenameMetadata(fileName);
    const today = new Date().toISOString().split('T')[0];
    
    // Check if cost sheet already exists
    const [existing] = await db
      .select()
      .from(costSheets)
      .where(eq(costSheets.driveFileId, driveFileId));
    
    let costSheet;
    if (existing) {
      // Update existing and delete old items
      await db.delete(costSheetItems).where(eq(costSheetItems.costSheetId, existing.id));
      
      [costSheet] = await db
        .update(costSheets)
        .set({ lastSynced: today })
        .where(eq(costSheets.id, existing.id))
        .returning();
    } else {
      // Create new cost sheet
      [costSheet] = await db
        .insert(costSheets)
        .values({
          jobNumber,
          client,
          event,
          driveFileId,
          fileName,
          date: today,
          lastSynced: today,
        })
        .returning();
    }

    // Parse Excel file
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: '' }) as any[][];

    // Find the header row - check row 9 first (0-indexed row 8), then search dynamically
    let headerRowIndex = -1;
    
    // First, check if row 9 (index 8) is the header row (this is the case for most files)
    if (rows.length > 8) {
      const row9Str = JSON.stringify(rows[8]).toLowerCase();
      if (row9Str.includes('description') && (row9Str.includes('qty') || row9Str.includes('cost'))) {
        headerRowIndex = 8;
      }
    }
    
    // If row 9 wasn't the header, search dynamically
    if (headerRowIndex === -1) {
      for (let i = 0; i < Math.min(rows.length, 20); i++) {
        const rowStr = JSON.stringify(rows[i]).toLowerCase();
        if (rowStr.includes('description') && (rowStr.includes('qty') || rowStr.includes('cost'))) {
          headerRowIndex = i;
          break;
        }
      }
    }

    if (headerRowIndex === -1) {
      console.warn(`⚠️  No header row found in ${fileName}`);
      return { success: true, rowsInserted: 0, rowsSkipped: rows.length };
    }

    const headerRow = rows[headerRowIndex];
    
    // Map column indices (case-insensitive matching)
    const getColIndex = (patterns: RegExp[]): number => {
      for (const pattern of patterns) {
        const index = headerRow.findIndex((h: any) => pattern.test(String(h).toLowerCase()));
        if (index !== -1) return index;
      }
      return -1;
    };

    const descCol = getColIndex([/description/i, /desc/i, /item/i, /particular/i]);
    const vendorCol = getColIndex([/vendor/i, /supplier/i]);
    const qtyCol = getColIndex([/qty/i, /quantity/i, /days?/i]);
    const unitCostCol = getColIndex([/unit.*cost/i, /cost.*unit/i, /unit.*price/i]);
    const totalCostCol = getColIndex([/total.*cost/i, /cost.*total/i, /total.*price/i]);
    const unitSellCol = getColIndex([/unit.*sell/i, /sell.*unit/i]);
    const totalSellCol = getColIndex([/total.*sell/i, /sell.*total/i]);

    // Collect all items to insert in batch
    const itemsToInsert: any[] = [];
    
    // Process data rows (after header)
    for (let i = headerRowIndex + 1; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row.length === 0) {
        rowsSkipped++;
        continue;
      }

      // Skip rows without description
      const description = descCol >= 0 ? String(row[descCol] || '').trim() : '';
      if (!description || description.toLowerCase().includes('total') || description.toLowerCase().includes('vat')) {
        rowsSkipped++;
        continue;
      }

      // Extract values
      const vendor = vendorCol >= 0 ? String(row[vendorCol] || '').trim() : null;
      const qty = qtyCol >= 0 ? parseFloat(String(row[qtyCol] || '0')) : null;
      const unitCost = unitCostCol >= 0 ? parseDecimal(row[unitCostCol]) : null;
      const totalCost = totalCostCol >= 0 ? parseDecimal(row[totalCostCol]) : null;
      const unitSelling = unitSellCol >= 0 ? parseDecimal(row[unitSellCol]) : null;
      const totalSelling = totalSellCol >= 0 ? parseDecimal(row[totalSellCol]) : null;

      itemsToInsert.push({
        costSheetId: costSheet.id,
        itemNumber: null,
        description,
        vendor: vendor || null,
        days: qty && !isNaN(qty) ? Math.round(qty) : null,
        unitCost,
        totalCost,
        unitSellingPrice: unitSelling,
        totalSellingPrice: totalSelling,
      });
    }
    
    // Batch insert all items
    if (itemsToInsert.length > 0) {
      try {
        await db.insert(costSheetItems).values(itemsToInsert);
        rowsInserted = itemsToInsert.length;
      } catch (e: any) {
        console.error(`Batch insert failed for ${fileName}:`, e.message);
        rowsSkipped += itemsToInsert.length;
      }
    }
    
    return { success: true, rowsInserted, rowsSkipped };
  } catch (e: any) {
    console.error(`File failed: ${fileName}`, e.message);
    return { success: false, rowsInserted, rowsSkipped, error: e.message };
  }
}

/**
 * Parse decimal value from Excel cell
 */
function parseDecimal(value: any): string | null {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  
  const cleaned = String(value).replace(/[,$]/g, '').trim();
  const parsed = parseFloat(cleaned);
  
  return isNaN(parsed) ? null : parsed.toFixed(2);
}

/**
 * Parse Excel file for upload endpoint (backwards compatibility)
 */
export function parseExcelFile(fileBuffer: Buffer, fileName: string): ParsedCostSheet {
  const { jobNumber, client, event } = parseFilenameMetadata(fileName);
  const items: Omit<InsertCostSheetItem, 'costSheetId'>[] = [];
  
  try {
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: '' }) as any[][];

    // Find header row
    let headerRowIndex = -1;
    for (let i = 0; i < Math.min(rows.length, 20); i++) {
      const rowStr = JSON.stringify(rows[i]).toLowerCase();
      if (rowStr.includes('description')) {
        headerRowIndex = i;
        break;
      }
    }

    if (headerRowIndex === -1) {
      return { costSheet: { jobNumber, client, event, date: null }, items: [] };
    }

    const headerRow = rows[headerRowIndex];
    const descCol = headerRow.findIndex((h: any) => /description/i.test(String(h)));
    const vendorCol = headerRow.findIndex((h: any) => /vendor|supplier/i.test(String(h)));
    const qtyCol = headerRow.findIndex((h: any) => /qty|quantity|days/i.test(String(h)));
    const unitCostCol = headerRow.findIndex((h: any) => /unit.*cost/i.test(String(h)));
    const totalCostCol = headerRow.findIndex((h: any) => /total.*cost/i.test(String(h)));

    for (let i = headerRowIndex + 1; i < rows.length; i++) {
      const row = rows[i];
      const description = descCol >= 0 ? String(row[descCol] || '').trim() : '';
      
      if (description && !description.toLowerCase().includes('total')) {
        items.push({
          itemNumber: null,
          description,
          vendor: vendorCol >= 0 ? String(row[vendorCol] || '').trim() || null : null,
          days: qtyCol >= 0 ? Math.round(parseFloat(String(row[qtyCol] || '0'))) : null,
          unitCost: unitCostCol >= 0 ? parseDecimal(row[unitCostCol]) : null,
          totalCost: totalCostCol >= 0 ? parseDecimal(row[totalCostCol]) : null,
          unitSellingPrice: null,
          totalSellingPrice: null,
        });
      }
    }
  } catch (e: any) {
    console.error('Parse error:', fileName, e.message);
  }
  
  return {
    costSheet: { jobNumber, client, event, date: null },
    items,
  };
}
