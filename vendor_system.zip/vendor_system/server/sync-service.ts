import { listExcelFilesInFolder, downloadFile, type DriveFile } from './drive-service';
import { parseAndInsertExcelFile } from './excel-parser';

export interface SyncResult {
  success: boolean;
  filesProcessed: number;
  filesSkipped: number;
  rowsInserted: number;
  rowsSkipped: number;
  errors: string[];
}

/**
 * Sync all cost sheets from Google Drive folder
 * Uses bulletproof parsing: reads every sheet, every row, skips nothing
 */
export async function syncCostSheets(folderId: string = '1SY44mewvsstdD4NQgpiSU6J4bTTNCXTT'): Promise<SyncResult> {
  const result: SyncResult = {
    success: false,
    filesProcessed: 0,
    filesSkipped: 0,
    rowsInserted: 0,
    rowsSkipped: 0,
    errors: [],
  };

  try {
    console.log(`🚀 Starting sync from Google Drive folder: ${folderId}`);

    // List all Excel files in the folder
    const files = await listExcelFilesInFolder(folderId);
    console.log(`📁 Found ${files.length} Excel files`);

    // Process each file
    let fileCount = 0;
    for (const file of files) {
      fileCount++;
      console.log(`\n📄 [${fileCount}/${files.length}] Processing: ${file.name}`);
      
      try {
        // Download file
        const fileBuffer = await downloadFile(file.id);
        
        // Parse and insert using bulletproof approach
        const parseResult = await parseAndInsertExcelFile(
          fileBuffer,
          file.name,
          file.id
        );
        
        if (parseResult.success) {
          result.filesProcessed++;
          result.rowsInserted += parseResult.rowsInserted;
          result.rowsSkipped += parseResult.rowsSkipped;
          console.log(`✅ Success: ${parseResult.rowsInserted} rows inserted, ${parseResult.rowsSkipped} rows skipped`);
        } else {
          result.filesSkipped++;
          result.errors.push(`${file.name}: ${parseResult.error}`);
          console.error(`❌ Failed: ${parseResult.error}`);
        }
      } catch (error) {
        const errorMsg = `${file.name}: ${error instanceof Error ? error.message : String(error)}`;
        console.error(`❌ Error: ${errorMsg}`);
        result.errors.push(errorMsg);
        result.filesSkipped++;
      }
    }

    result.success = result.filesProcessed > 0;
    
    console.log(`\n📊 Sync Complete:`);
    console.log(`   ✅ Files processed: ${result.filesProcessed}`);
    console.log(`   ⏭️  Files skipped: ${result.filesSkipped}`);
    console.log(`   📝 Rows inserted: ${result.rowsInserted}`);
    console.log(`   ⚠️  Rows skipped: ${result.rowsSkipped}`);
    console.log(`   ❌ Errors: ${result.errors.length}`);

    return result;
  } catch (error) {
    const errorMsg = `Sync failed: ${error instanceof Error ? error.message : String(error)}`;
    console.error(`❌ ${errorMsg}`);
    result.errors.push(errorMsg);
    return result;
  }
}
