import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { parseVendorExcel, deduplicateVendors } from "./import-vendors";
import { storage } from "./storage";
import * as fs from "fs";

const app = express();

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Auto-import vendors on startup from bundled vendor Excel file
  // This file is expected to be present as part of the application deployment
  const vendorExcelPath = "attached_assets/Vendor Contact Details - 2025_1761319476363.xlsx";
  if (fs.existsSync(vendorExcelPath)) {
    try {
      log("Importing vendors from bundled Excel file...");
      const vendors = parseVendorExcel(vendorExcelPath);
      const uniqueVendors = deduplicateVendors(vendors);
      
      // Clear existing sample data and import real vendors
      const existingVendors = await storage.getVendors();
      if (existingVendors.length > 0) {
        log(`Clearing ${existingVendors.length} existing vendors...`);
        for (const vendor of existingVendors) {
          await storage.deleteVendor(vendor.id);
        }
      }
      
      for (const vendorData of uniqueVendors) {
        await storage.createVendor(vendorData);
      }
      
      log(`Successfully imported ${uniqueVendors.length} vendors from Excel file`);
    } catch (error) {
      log(`FATAL ERROR: Failed to import vendors from bundled Excel file: ${error}`);
      throw error; // Fail fast on startup if vendor import fails
    }
  } else {
    log(`WARNING: Vendor Excel file not found at ${vendorExcelPath}. Using sample vendor data.`);
  }

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
