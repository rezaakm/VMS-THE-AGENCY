import XLSX from 'xlsx';
import { InsertVendor } from '@shared/schema';

interface VendorRow {
  slNo: string | number;
  vendorName: string;
  contactPerson: string;
  department: string;
  jobDescription: string;
  contactNumber: string | number;
  mailId: string;
}

function normalizePhone(phone: string | number): string {
  if (!phone) return '';
  const phoneStr = String(phone).trim();
  // Remove spaces and format consistently
  return phoneStr.replace(/\s+/g, '');
}

function categorizeVendor(department: string, jobDescription: string): string {
  const dept = (department || '').toLowerCase();
  const job = (jobDescription || '').toLowerCase();
  
  // Map departments to categories
  if (dept.includes('carpentry') || job.includes('carpentor') || job.includes('carpenter')) {
    return 'Carpentry';
  }
  if (dept.includes('production') || job.includes('fabrication')) {
    return 'Production & Fabrication';
  }
  if (job.includes('printing') || job.includes('print')) {
    return 'Printing';
  }
  if (dept.includes('lighting') || job.includes('lighting')) {
    return 'Lighting';
  }
  if (dept.includes('audio') || dept.includes('sound')) {
    return 'Audio & Sound';
  }
  if (dept.includes('video') || job.includes('video')) {
    return 'Video & AV';
  }
  if (dept.includes('logistics') || job.includes('transport')) {
    return 'Logistics';
  }
  if (dept.includes('catering') || job.includes('food')) {
    return 'Catering';
  }
  if (dept.includes('decor') || job.includes('decoration')) {
    return 'Decoration';
  }
  if (dept.includes('rental') || job.includes('rent')) {
    return 'Equipment Rental';
  }
  
  // Default fallback
  return department || 'General Services';
}

export function parseVendorExcel(filePath: string): InsertVendor[] {
  const workbook = XLSX.readFile(filePath);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const data = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }) as any[][];
  
  const vendors: InsertVendor[] = [];
  
  // Skip first 3 rows (title, subtitle, header)
  for (let i = 3; i < data.length; i++) {
    const row = data[i];
    
    // Skip empty rows (no vendor name)
    if (!row[1] || String(row[1]).trim() === '') {
      continue;
    }
    
    const vendorName = String(row[1]).trim();
    const contactPerson = String(row[2] || '').trim();
    const department = String(row[3] || '').trim();
    const jobDescription = String(row[4] || '').trim();
    const contactNumber = normalizePhone(row[5]);
    const mailId = String(row[6] || '').trim();
    
    const vendor: InsertVendor = {
      name: vendorName,
      category: categorizeVendor(department, jobDescription),
      status: 'active',
      email: mailId || undefined,
      phone: contactNumber || undefined,
      website: undefined,
      address: undefined,
      contactPerson: contactPerson || undefined,
      rating: 0,
      notes: jobDescription ? `Department: ${department}. ${jobDescription}` : undefined,
    };
    
    vendors.push(vendor);
  }
  
  return vendors;
}

export function deduplicateVendors(vendors: InsertVendor[]): InsertVendor[] {
  const uniqueVendors = new Map<string, InsertVendor>();
  
  for (const vendor of vendors) {
    const key = vendor.name.toLowerCase().trim();
    
    if (!uniqueVendors.has(key)) {
      uniqueVendors.set(key, vendor);
    } else {
      // If duplicate found, merge contact information
      const existing = uniqueVendors.get(key)!;
      
      // Prefer non-empty email
      if (!existing.email && vendor.email) {
        existing.email = vendor.email;
      }
      
      // Prefer non-empty phone
      if (!existing.phone && vendor.phone) {
        existing.phone = vendor.phone;
      }
      
      // Prefer non-empty contact person
      if (!existing.contactPerson && vendor.contactPerson) {
        existing.contactPerson = vendor.contactPerson;
      }
      
      // Append notes if different
      if (vendor.notes && vendor.notes !== existing.notes) {
        existing.notes = existing.notes 
          ? `${existing.notes}\n${vendor.notes}` 
          : vendor.notes;
      }
    }
  }
  
  return Array.from(uniqueVendors.values());
}
