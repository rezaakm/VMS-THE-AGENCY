import {
  type Vendor,
  type InsertVendor,
  type Contract,
  type InsertContract,
  type Contact,
  type InsertContact,
  type PerformanceMetric,
  type InsertPerformanceMetric,
  type CostSheet,
  type InsertCostSheet,
  type CostSheetItem,
  type InsertCostSheetItem,
  type User,
  type UpsertUser,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Vendors
  getVendors(): Promise<Vendor[]>;
  getVendor(id: string): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  updateVendor(id: string, vendor: Partial<InsertVendor>): Promise<Vendor | undefined>;
  deleteVendor(id: string): Promise<boolean>;

  // Contracts
  getContracts(): Promise<Contract[]>;
  getContract(id: string): Promise<Contract | undefined>;
  getContractsByVendor(vendorId: string): Promise<Contract[]>;
  createContract(contract: InsertContract): Promise<Contract>;
  updateContract(id: string, contract: Partial<InsertContract>): Promise<Contract | undefined>;
  deleteContract(id: string): Promise<boolean>;

  // Contacts
  getContacts(): Promise<Contact[]>;
  getContact(id: string): Promise<Contact | undefined>;
  getContactsByVendor(vendorId: string): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: string, contact: Partial<InsertContact>): Promise<Contact | undefined>;
  deleteContact(id: string): Promise<boolean>;

  // Performance Metrics
  getPerformanceMetrics(): Promise<PerformanceMetric[]>;
  getPerformanceMetric(id: string): Promise<PerformanceMetric | undefined>;
  getPerformanceMetricsByVendor(vendorId: string): Promise<PerformanceMetric[]>;
  createPerformanceMetric(metric: InsertPerformanceMetric): Promise<PerformanceMetric>;
  updatePerformanceMetric(id: string, metric: Partial<InsertPerformanceMetric>): Promise<PerformanceMetric | undefined>;
  deletePerformanceMetric(id: string): Promise<boolean>;

  // Cost Sheets
  getCostSheets(): Promise<CostSheet[]>;
  getCostSheet(id: string): Promise<CostSheet | undefined>;
  getCostSheetByFileId(driveFileId: string): Promise<CostSheet | undefined>;
  createCostSheet(costSheet: InsertCostSheet): Promise<CostSheet>;
  updateCostSheet(id: string, costSheet: Partial<InsertCostSheet>): Promise<CostSheet | undefined>;
  deleteCostSheet(id: string): Promise<boolean>;

  // Cost Sheet Items
  getCostSheetItems(): Promise<CostSheetItem[]>;
  getCostSheetItem(id: string): Promise<CostSheetItem | undefined>;
  getCostSheetItemsBySheet(costSheetId: string): Promise<CostSheetItem[]>;
  searchCostSheetItems(
    query: string,
    filters?: {
      vendor?: string;
      minPrice?: number;
      maxPrice?: number;
      jobNumber?: string;
      client?: string;
    }
  ): Promise<CostSheetItem[]>;
  createCostSheetItem(item: InsertCostSheetItem): Promise<CostSheetItem>;
  createCostSheetItems(items: InsertCostSheetItem[]): Promise<CostSheetItem[]>;
  deleteCostSheetItem(id: string): Promise<boolean>;
  deleteCostSheetItems(ids: string[]): Promise<number>;
  deleteCostSheetItemsBySheet(costSheetId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private vendors: Map<string, Vendor>;
  private contracts: Map<string, Contract>;
  private contacts: Map<string, Contact>;
  private performanceMetrics: Map<string, PerformanceMetric>;
  private costSheets: Map<string, CostSheet>;
  private costSheetItems: Map<string, CostSheetItem>;

  constructor() {
    this.users = new Map();
    this.vendors = new Map();
    this.contracts = new Map();
    this.contacts = new Map();
    this.performanceMetrics = new Map();
    this.costSheets = new Map();
    this.costSheetItems = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed some sample vendors
    const vendor1: Vendor = {
      id: randomUUID(),
      name: "TechCorp Solutions",
      category: "Technology",
      status: "active",
      email: "contact@techcorp.com",
      phone: "+1 (555) 123-4567",
      website: "https://techcorp.com",
      address: "123 Tech Street, San Francisco, CA 94105",
      contactPerson: "Sarah Johnson",
      rating: 5,
      notes: "Excellent technology partner with reliable service delivery",
    };

    const vendor2: Vendor = {
      id: randomUUID(),
      name: "Global Logistics Inc",
      category: "Logistics",
      status: "active",
      email: "info@globallogistics.com",
      phone: "+1 (555) 234-5678",
      website: "https://globallogistics.com",
      address: "456 Shipping Lane, Newark, NJ 07102",
      contactPerson: "Michael Chen",
      rating: 4,
      notes: "Fast and reliable shipping services",
    };

    const vendor3: Vendor = {
      id: randomUUID(),
      name: "Marketing Pros",
      category: "Marketing",
      status: "active",
      email: "hello@marketingpros.com",
      phone: "+1 (555) 345-6789",
      website: "https://marketingpros.com",
      address: "789 Creative Ave, New York, NY 10001",
      contactPerson: "Emily Rodriguez",
      rating: 4,
      notes: "Creative marketing campaigns with great ROI",
    };

    this.vendors.set(vendor1.id, vendor1);
    this.vendors.set(vendor2.id, vendor2);
    this.vendors.set(vendor3.id, vendor3);

    // Seed some contracts
    const contract1: Contract = {
      id: randomUUID(),
      vendorId: vendor1.id,
      name: "Annual Software License",
      value: "50000",
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      status: "active",
      terms: "12-month software licensing agreement with maintenance and support",
      renewalStatus: "auto-renew",
    };

    const contract2: Contract = {
      id: randomUUID(),
      vendorId: vendor2.id,
      name: "Shipping Services Agreement",
      value: "120000",
      startDate: "2024-06-01",
      endDate: "2025-05-31",
      status: "active",
      terms: "Annual shipping and logistics services with volume discounts",
      renewalStatus: "manual",
    };

    this.contracts.set(contract1.id, contract1);
    this.contracts.set(contract2.id, contract2);

    // Seed some contacts
    const contact1: Contact = {
      id: randomUUID(),
      vendorId: vendor1.id,
      name: "Sarah Johnson",
      title: "Account Manager",
      email: "sarah.johnson@techcorp.com",
      phone: "+1 (555) 123-4567",
      isPrimary: 1,
    };

    const contact2: Contact = {
      id: randomUUID(),
      vendorId: vendor2.id,
      name: "Michael Chen",
      title: "Operations Director",
      email: "m.chen@globallogistics.com",
      phone: "+1 (555) 234-5678",
      isPrimary: 1,
    };

    this.contacts.set(contact1.id, contact1);
    this.contacts.set(contact2.id, contact2);
  }

  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const id = userData.id || randomUUID();
    const existing = this.users.get(id);
    const now = new Date();
    
    const user: User = {
      ...existing,
      ...userData,
      id,
      email: userData.email ?? null,
      firstName: userData.firstName ?? null,
      lastName: userData.lastName ?? null,
      profileImageUrl: userData.profileImageUrl ?? null,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    };
    
    this.users.set(id, user);
    return user;
  }

  // Vendors
  async getVendors(): Promise<Vendor[]> {
    return Array.from(this.vendors.values());
  }

  async getVendor(id: string): Promise<Vendor | undefined> {
    return this.vendors.get(id);
  }

  async createVendor(insertVendor: InsertVendor): Promise<Vendor> {
    const id = randomUUID();
    const vendor: Vendor = {
      id,
      name: insertVendor.name,
      category: insertVendor.category,
      status: insertVendor.status ?? "active",
      email: insertVendor.email ?? null,
      phone: insertVendor.phone ?? null,
      website: insertVendor.website ?? null,
      address: insertVendor.address ?? null,
      contactPerson: insertVendor.contactPerson ?? null,
      rating: insertVendor.rating ?? null,
      notes: insertVendor.notes ?? null,
    };
    this.vendors.set(id, vendor);
    return vendor;
  }

  async updateVendor(id: string, updates: Partial<InsertVendor>): Promise<Vendor | undefined> {
    const vendor = this.vendors.get(id);
    if (!vendor) return undefined;
    const updated = { ...vendor, ...updates };
    this.vendors.set(id, updated);
    return updated;
  }

  async deleteVendor(id: string): Promise<boolean> {
    return this.vendors.delete(id);
  }

  // Contracts
  async getContracts(): Promise<Contract[]> {
    return Array.from(this.contracts.values());
  }

  async getContract(id: string): Promise<Contract | undefined> {
    return this.contracts.get(id);
  }

  async getContractsByVendor(vendorId: string): Promise<Contract[]> {
    return Array.from(this.contracts.values()).filter((c) => c.vendorId === vendorId);
  }

  async createContract(insertContract: InsertContract): Promise<Contract> {
    const id = randomUUID();
    const contract: Contract = {
      id,
      vendorId: insertContract.vendorId,
      name: insertContract.name,
      value: insertContract.value,
      startDate: insertContract.startDate,
      endDate: insertContract.endDate,
      status: insertContract.status ?? "active",
      terms: insertContract.terms ?? null,
      renewalStatus: insertContract.renewalStatus ?? null,
    };
    this.contracts.set(id, contract);
    return contract;
  }

  async updateContract(id: string, updates: Partial<InsertContract>): Promise<Contract | undefined> {
    const contract = this.contracts.get(id);
    if (!contract) return undefined;
    const updated = { ...contract, ...updates };
    this.contracts.set(id, updated);
    return updated;
  }

  async deleteContract(id: string): Promise<boolean> {
    return this.contracts.delete(id);
  }

  // Contacts
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async getContact(id: string): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async getContactsByVendor(vendorId: string): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter((c) => c.vendorId === vendorId);
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = {
      id,
      vendorId: insertContact.vendorId,
      name: insertContact.name,
      email: insertContact.email,
      title: insertContact.title ?? null,
      phone: insertContact.phone ?? null,
      isPrimary: insertContact.isPrimary ?? null,
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async updateContact(id: string, updates: Partial<InsertContact>): Promise<Contact | undefined> {
    const contact = this.contacts.get(id);
    if (!contact) return undefined;
    const updated = { ...contact, ...updates };
    this.contacts.set(id, updated);
    return updated;
  }

  async deleteContact(id: string): Promise<boolean> {
    return this.contacts.delete(id);
  }

  // Performance Metrics
  async getPerformanceMetrics(): Promise<PerformanceMetric[]> {
    return Array.from(this.performanceMetrics.values());
  }

  async getPerformanceMetric(id: string): Promise<PerformanceMetric | undefined> {
    return this.performanceMetrics.get(id);
  }

  async getPerformanceMetricsByVendor(vendorId: string): Promise<PerformanceMetric[]> {
    return Array.from(this.performanceMetrics.values()).filter((m) => m.vendorId === vendorId);
  }

  async createPerformanceMetric(insertMetric: InsertPerformanceMetric): Promise<PerformanceMetric> {
    const id = randomUUID();
    const metric: PerformanceMetric = {
      id,
      vendorId: insertMetric.vendorId,
      metricDate: insertMetric.metricDate,
      deliveryScore: insertMetric.deliveryScore ?? null,
      qualityScore: insertMetric.qualityScore ?? null,
      responseTime: insertMetric.responseTime ?? null,
      notes: insertMetric.notes ?? null,
    };
    this.performanceMetrics.set(id, metric);
    return metric;
  }

  async updatePerformanceMetric(id: string, updates: Partial<InsertPerformanceMetric>): Promise<PerformanceMetric | undefined> {
    const metric = this.performanceMetrics.get(id);
    if (!metric) return undefined;
    const updated = { ...metric, ...updates };
    this.performanceMetrics.set(id, updated);
    return updated;
  }

  async deletePerformanceMetric(id: string): Promise<boolean> {
    return this.performanceMetrics.delete(id);
  }

  // Cost Sheets
  async getCostSheets(): Promise<CostSheet[]> {
    return Array.from(this.costSheets.values());
  }

  async getCostSheet(id: string): Promise<CostSheet | undefined> {
    return this.costSheets.get(id);
  }

  async getCostSheetByFileId(driveFileId: string): Promise<CostSheet | undefined> {
    return Array.from(this.costSheets.values()).find((cs) => cs.driveFileId === driveFileId);
  }

  async createCostSheet(insertCostSheet: InsertCostSheet): Promise<CostSheet> {
    const id = randomUUID();
    const costSheet: CostSheet = {
      id,
      jobNumber: insertCostSheet.jobNumber,
      client: insertCostSheet.client,
      event: insertCostSheet.event,
      date: insertCostSheet.date ?? null,
      driveFileId: insertCostSheet.driveFileId,
      fileName: insertCostSheet.fileName,
      lastSynced: new Date().toISOString().split('T')[0],
    };
    this.costSheets.set(id, costSheet);
    return costSheet;
  }

  async updateCostSheet(id: string, updates: Partial<InsertCostSheet>): Promise<CostSheet | undefined> {
    const costSheet = this.costSheets.get(id);
    if (!costSheet) return undefined;
    const updated = { ...costSheet, ...updates };
    this.costSheets.set(id, updated);
    return updated;
  }

  async deleteCostSheet(id: string): Promise<boolean> {
    return this.costSheets.delete(id);
  }

  // Cost Sheet Items
  async getCostSheetItems(): Promise<CostSheetItem[]> {
    return Array.from(this.costSheetItems.values());
  }

  async getCostSheetItem(id: string): Promise<CostSheetItem | undefined> {
    return this.costSheetItems.get(id);
  }

  async getCostSheetItemsBySheet(costSheetId: string): Promise<CostSheetItem[]> {
    return Array.from(this.costSheetItems.values()).filter((item) => item.costSheetId === costSheetId);
  }

  async searchCostSheetItems(
    query: string,
    filters?: {
      vendor?: string;
      minPrice?: number;
      maxPrice?: number;
      jobNumber?: string;
      client?: string;
    }
  ): Promise<CostSheetItem[]> {
    const lowerQuery = query.toLowerCase();
    const items = Array.from(this.costSheetItems.values()).filter((item) => {
      // Text search
      const matchesQuery = item.description.toLowerCase().includes(lowerQuery) ||
        (item.vendor && item.vendor.toLowerCase().includes(lowerQuery));
      
      if (!matchesQuery) return false;

      // Vendor filter
      if (filters?.vendor) {
        const vendorMatch = item.vendor?.toLowerCase().includes(filters.vendor.toLowerCase());
        if (!vendorMatch) return false;
      }

      // Price range filter (using totalSellingPrice)
      if (filters?.minPrice !== undefined || filters?.maxPrice !== undefined) {
        const price = item.totalSellingPrice ? parseFloat(item.totalSellingPrice) : null;
        if (price === null) return false;
        
        if (filters.minPrice !== undefined && price < filters.minPrice) return false;
        if (filters.maxPrice !== undefined && price > filters.maxPrice) return false;
      }

      return true;
    });

    // Apply job/client filters if provided (requires fetching cost sheet)
    if (filters?.jobNumber || filters?.client) {
      const filteredItems: CostSheetItem[] = [];
      for (const item of items) {
        const costSheet = await this.getCostSheet(item.costSheetId);
        if (!costSheet) continue;

        let matches = true;
        if (filters.jobNumber && !costSheet.jobNumber.toLowerCase().includes(filters.jobNumber.toLowerCase())) {
          matches = false;
        }
        if (filters.client && !costSheet.client.toLowerCase().includes(filters.client.toLowerCase())) {
          matches = false;
        }

        if (matches) filteredItems.push(item);
      }
      return filteredItems;
    }

    return items;
  }

  async createCostSheetItem(insertItem: InsertCostSheetItem): Promise<CostSheetItem> {
    const id = randomUUID();
    const item: CostSheetItem = {
      id,
      costSheetId: insertItem.costSheetId,
      itemNumber: insertItem.itemNumber ?? null,
      description: insertItem.description,
      vendor: insertItem.vendor ?? null,
      days: insertItem.days ?? null,
      unitCost: insertItem.unitCost ?? null,
      totalCost: insertItem.totalCost ?? null,
      unitSellingPrice: insertItem.unitSellingPrice ?? null,
      totalSellingPrice: insertItem.totalSellingPrice ?? null,
    };
    this.costSheetItems.set(id, item);
    return item;
  }

  async createCostSheetItems(insertItems: InsertCostSheetItem[]): Promise<CostSheetItem[]> {
    const items: CostSheetItem[] = [];
    for (const insertItem of insertItems) {
      const id = randomUUID();
      const item: CostSheetItem = {
        id,
        costSheetId: insertItem.costSheetId,
        itemNumber: insertItem.itemNumber ?? null,
        description: insertItem.description,
        vendor: insertItem.vendor ?? null,
        days: insertItem.days ?? null,
        unitCost: insertItem.unitCost ?? null,
        totalCost: insertItem.totalCost ?? null,
        unitSellingPrice: insertItem.unitSellingPrice ?? null,
        totalSellingPrice: insertItem.totalSellingPrice ?? null,
      };
      this.costSheetItems.set(id, item);
      items.push(item);
    }
    return items;
  }

  async deleteCostSheetItem(id: string): Promise<boolean> {
    return this.costSheetItems.delete(id);
  }

  async deleteCostSheetItems(ids: string[]): Promise<number> {
    let deleted = 0;
    for (const id of ids) {
      if (this.costSheetItems.delete(id)) {
        deleted++;
      }
    }
    return deleted;
  }

  async deleteCostSheetItemsBySheet(costSheetId: string): Promise<boolean> {
    const items = await this.getCostSheetItemsBySheet(costSheetId);
    for (const item of items) {
      this.costSheetItems.delete(item.id);
    }
    return true;
  }
}

export const storage = new MemStorage();
