import OpenAI from "openai";
import { z } from "zod";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const MODEL = "gpt-5";

const parsedQuerySchema = z.object({
  keywords: z.array(z.string()).default([]),
  vendor: z.string().nullable().default(null),
  category: z.string().nullable().default(null),
  price_min: z.number().nullable().default(null),
  price_max: z.number().nullable().default(null),
  date_from: z.string().nullable().default(null),
  date_to: z.string().nullable().default(null),
  exclude_terms: z.array(z.string()).default([]),
  sort: z.array(z.object({
    field: z.string(),
    dir: z.enum(["asc", "desc"])
  })).default([]),
  limit: z.number().min(1).max(500).default(200)
});

const normalizedItemSchema = z.object({
  canonical_item: z.string().nullable().default(null),
  dimensions: z.string().nullable().default(null),
  material: z.string().nullable().default(null),
  tags: z.array(z.string()).default([])
});

const estimateItemSchema = z.object({
  item: z.string(),
  qty: z.number().min(1).default(1),
  tags: z.array(z.string()).default([]),
  budget: z.number().nullable().default(null)
});

export type ParsedQuery = z.infer<typeof parsedQuerySchema>;
export type NormalizedItem = z.infer<typeof normalizedItemSchema>;
export type EstimateItem = z.infer<typeof estimateItemSchema>;

export async function parseNaturalLanguageQuery(query: string): Promise<ParsedQuery> {
  const systemPrompt = `You are a structured query composer for a vendor management app. You must translate user text into valid JSON filters that match the given schema. Only return valid JSON. Do not include commentary.`;

  const userPrompt = `Convert this search query into structured filters: "${query}"

Return JSON with these fields:
- keywords: array of search terms
- vendor: vendor name or null
- category: category name or null
- price_min: minimum price or null
- price_max: maximum price or null
- date_from: start date (YYYY-MM-DD) or null
- date_to: end date (YYYY-MM-DD) or null
- exclude_terms: array of terms to exclude
- sort: array of {field, dir} objects
- limit: number (default 200, max 500)`;

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1000,
    });

    const result = completion.choices[0]?.message?.content;
    if (!result) {
      throw new Error("No response from AI");
    }

    const rawParsed = JSON.parse(result);
    const validated = parsedQuerySchema.parse(rawParsed);
    return validated;
  } catch (error) {
    console.error("Error parsing natural language query:", error);
    throw new Error("Failed to parse query");
  }
}

export async function normalizeItem(
  item: string,
  vendor?: string,
  price?: string | number
): Promise<NormalizedItem> {
  const systemPrompt = `You are a product normalization assistant. Extract canonical item details from text. Return JSON with no commentary.`;

  const userPrompt = `Normalize this item:
Item: "${item}"
${vendor ? `Vendor: "${vendor}"` : ""}
${price ? `Price: "${price}"` : ""}

Return JSON with:
- canonical_item: simplified, standardized item name
- dimensions: extracted dimensions (e.g., "4x3m") or null
- material: detected material or null
- tags: array of relevant tags`;

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 500,
    });

    const result = completion.choices[0]?.message?.content;
    if (!result) {
      throw new Error("No response from AI");
    }

    const rawParsed = JSON.parse(result);
    const validated = normalizedItemSchema.parse(rawParsed);
    return validated;
  } catch (error) {
    console.error("Error normalizing item:", error);
    throw new Error("Failed to normalize item");
  }
}

export async function extractEstimate(text: string): Promise<EstimateItem[]> {
  const systemPrompt = `You are an estimator assistant. Extract requested items from client text into structured JSON cart items.`;

  const userPrompt = `Extract items from this client brief:
"${text}"

Return a JSON array where each item has:
- item: description of the item/service
- qty: quantity (number)
- tags: array of relevant tags
- budget: budget amount or null

Focus on extracting specific items, quantities, and any budget constraints mentioned.`;

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2000,
    });

    const result = completion.choices[0]?.message?.content;
    if (!result) {
      throw new Error("No response from AI");
    }

    // The AI might wrap the array in an object with an "items" key
    const rawParsed = JSON.parse(result);
    const items = Array.isArray(rawParsed) ? rawParsed : (rawParsed.items || []);
    
    // Validate each item with Zod
    return items.map((item: any) => estimateItemSchema.parse(item));
  } catch (error) {
    console.error("Error extracting estimate:", error);
    throw new Error("Failed to extract estimate");
  }
}
