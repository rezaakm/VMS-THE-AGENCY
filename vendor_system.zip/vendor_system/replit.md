# Vendor Management System

## Overview
This is an enterprise B2B vendor management application designed to track vendor relationships, contracts, contacts, and performance metrics. The application provides comprehensive vendor lifecycle management including contract tracking, contact management, and performance monitoring, with a CRM-style interface inspired by Salesforce and HubSpot. Key capabilities include AI-powered natural language search for vendors, email/brief text extraction for automatic contract item generation, vendor comparison with AI assistant, vendor cost trend visualization, and Google Drive integration for cost sheet search across 467 Excel files. The project aims to enhance data clarity, streamline workflows, and improve professional credibility.

## Recent Updates

**October 28, 2025 - Vendor Cost Trend Chart:**
- Added interactive cost trend visualization to Dashboard using Recharts
- GET /api/vendor-trend endpoint: aggregates monthly spending by vendor from cost sheet data
- Supports dual-vendor comparison with line chart showing cost trends over time
- Calculates month-over-month trend percentages with visual indicators (up/down arrows)
- Responsive design with mobile-friendly dropdowns and tooltips
- Real-time data from 2,977 cost sheet items across all historical jobs
- Helps identify spending patterns, seasonal variations, and vendor cost comparisons

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built with React 18 and TypeScript, using Vite for building and Wouter for client-side routing in a Single Page Application (SPA) architecture. State management and data fetching are handled by TanStack Query, with form state managed by React Hook Form and Zod validation. The UI leverages Shadcn/ui (New York style) built on Radix UI primitives, styled with Tailwind CSS, and supports light/dark mode. The design prioritizes a professional B2B aesthetic with a specific color palette. The application is optimized for mobile, tablet, and desktop breakpoints.

### Backend Architecture
The backend uses an Express.js server with a RESTful API design, employing JSON for requests/responses and Zod for schema validation. An AI service layer (server/ai-service.ts) integrates OpenAI via Replit integrations for natural language query parsing, item normalization, and estimate extraction, with strict Zod validation of AI responses. The application uses PostgreSQL as the target database via the Neon serverless driver, with Drizzle ORM for type-safe database operations and migrations. Authentication is handled by Replit Auth with Google Sign-In, restricting access to specific email domains.

### Data Storage
PostgreSQL is the primary database, managed with Drizzle ORM. The schema includes `Vendors`, `Contracts`, `Contacts`, and `Performance Metrics` tables, with defined one-to-many relationships. Drizzle Kit is used for schema management and migrations. Cost sheet data, parsed from Google Drive Excel files, is also stored, including dynamic header detection and metadata extraction.

### System Design Choices
- **UI/UX**: CRM-style interface, responsive design across devices, professional B2B aesthetic with specific color palette.
- **Technical Implementations**: Replit Auth with Google Sign-In, AI-powered features via OpenAI and Replit AI Integrations with Zod validation, Google Drive integration for Excel file processing, Excel parsing with dynamic header detection and robust error handling, batch database inserts.
- **Feature Specifications**: Natural language search with advanced filtering, email/brief text extraction for contracts, AI normalization endpoint, vendor comparison with AI assistant, comprehensive vendor lifecycle management, cost sheet search and estimate creation, vendor import from Excel.
- **Email Integration**: SendGrid and Twilio integrations were removed per user request. Email broadcast features are not implemented.

## External Dependencies

- **Database & ORM**: `@neondatabase/serverless`, `drizzle-orm`, `drizzle-kit`
- **UI Component Libraries**: `@radix-ui/*`, `embla-carousel-react`, `cmdk`, `lucide-react`
- **Form Handling & Validation**: `react-hook-form`, `@hookform/resolvers`, `zod`, `drizzle-zod`
- **Styling & Utilities**: `tailwindcss`, `class-variance-authority`, `clsx`, `tailwind-merge`, `date-fns`
- **State & Data Management**: `@tanstack/react-query`
- **Development Tools**: `@replit/vite-plugin-*`, `typescript`, `tsx`
- **Routing**: `wouter`
- **Build & Bundling**: `vite`, `@vitejs/plugin-react`, `esbuild`
- **AI Integration**: `openai` (via Replit AI Integrations)
- **Fonts**: Google Fonts CDN (Inter, Open Sans)