# Installation Guide: Node.js and PostgreSQL

## 🚀 Quick Install Guide

### Option 1: Install Node.js (Required)

#### Method 1: Official Installer (Recommended)

1. **Download Node.js:**
   - Visit: https://nodejs.org/
   - Download the **LTS version** (Long Term Support) - Recommended for most users
   - Choose the **Windows Installer (.msi)** for 64-bit

2. **Install Node.js:**
   - Run the downloaded `.msi` file
   - Click "Next" through the installation wizard
   - **Important:** Make sure to check "Add to PATH" option (should be checked by default)
   - Click "Install"
   - Wait for installation to complete

3. **Verify Installation:**
   ```powershell
   # Close and reopen PowerShell, then run:
   node --version
   npm --version
   ```
   You should see version numbers (e.g., v18.17.0 and 9.6.7)

#### Method 2: Using Chocolatey (If you have it)

```powershell
choco install nodejs-lts
```

#### Method 3: Using Winget (Windows Package Manager)

```powershell
winget install OpenJS.NodeJS.LTS
```

---

### Option 2: Install PostgreSQL (Required)

#### Method 1: Official Installer (Recommended)

1. **Download PostgreSQL:**
   - Visit: https://www.postgresql.org/download/windows/
   - Click on "Download the installer"
   - Download **PostgreSQL 15 or 16** (latest stable version)
   - Choose the Windows x86-64 installer

2. **Install PostgreSQL:**
   - Run the downloaded installer
   - **Set Installation Directory:** Leave default (usually `C:\Program Files\PostgreSQL\15`)
   - **Select Components:** Keep all checked (PostgreSQL Server, pgAdmin 4, Stack Builder, Command Line Tools)
   - **Set Data Directory:** Leave default
   - **Set Password:** 
     - **IMPORTANT:** Remember this password! You'll need it later.
     - Set password to: `postgres` (or your own secure password)
   - **Set Port:** Leave default (5432)
   - **Set Locale:** Leave default
   - Click "Next" through remaining steps
   - Wait for installation to complete

3. **Verify Installation:**
   ```powershell
   # Close and reopen PowerShell, then run:
   psql --version
   ```

4. **Set Environment Variables (If needed):**
   If `psql` command doesn't work:
   - Add to PATH: `C:\Program Files\PostgreSQL\15\bin`
   - Or restart your computer after installation

#### Method 2: Using Chocolatey

```powershell
choco install postgresql15
```

#### Method 3: Using Winget

```powershell
winget install PostgreSQL.PostgreSQL
```

---

## 📋 Post-Installation Setup

### 1. Setup PostgreSQL Database

After PostgreSQL installation, create the database for VMS:

1. **Open pgAdmin 4** (installed with PostgreSQL) or use psql command line:

**Using pgAdmin 4:**
- Open pgAdmin 4 from Start Menu
- Enter the password you set during installation
- Right-click on "Databases" → Create → Database
- Name: `vms_db`
- Click "Save"

**Using Command Line (psql):**
```powershell
# Connect to PostgreSQL (password: what you set during installation)
psql -U postgres

# Then run these SQL commands:
CREATE DATABASE vms_db;
CREATE USER vms_user WITH PASSWORD 'vms_password';
GRANT ALL PRIVILEGES ON DATABASE vms_db TO vms_user;
\q
```

### 2. Verify Node.js Installation

```powershell
# Check Node.js version (should be 18+)
node --version

# Check npm version
npm --version

# Update npm to latest (optional)
npm install -g npm@latest
```

### 3. Verify PostgreSQL Connection

```powershell
# Test connection (will prompt for password)
psql -U postgres -d vms_db

# If successful, you'll see:
# vms_db=#
# Type \q to exit
```

---

## 🧪 Quick Test

After installation, test everything:

```powershell
# 1. Test Node.js
node --version
npm --version

# 2. Test PostgreSQL
psql --version

# 3. Test Database Connection
psql -U postgres -d vms_db
# (Enter your password when prompted)
# Type: \q to exit
```

---

## 🐛 Troubleshooting

### Node.js Issues

**Problem:** `node` command not found after installation
- **Solution:** Restart PowerShell/Command Prompt
- **Solution:** Restart your computer
- **Solution:** Manually add to PATH: `C:\Program Files\nodejs\`

**Problem:** npm not found
- **Solution:** Node.js installer should include npm. Try reinstalling Node.js

### PostgreSQL Issues

**Problem:** `psql` command not found
- **Solution:** Add to PATH: `C:\Program Files\PostgreSQL\15\bin` (adjust version number)
- **Solution:** Restart your computer
- **Solution:** Use full path: `"C:\Program Files\PostgreSQL\15\bin\psql.exe"`

**Problem:** Can't connect to database
- **Solution:** Make sure PostgreSQL service is running:
  ```powershell
  # Check if service is running
  Get-Service postgresql*
  
  # Start service if stopped
  Start-Service postgresql-x64-15
  ```

**Problem:** Authentication failed
- **Solution:** Use the password you set during installation
- **Solution:** Default user is `postgres`

### Port Already in Use

**Problem:** Port 5432 already in use (PostgreSQL)
- **Solution:** Check what's using the port:
  ```powershell
  netstat -ano | findstr :5432
  ```
- **Solution:** Change PostgreSQL port in `postgresql.conf` or use different port

---

## ✅ Installation Checklist

- [ ] Node.js installed and verified (`node --version`)
- [ ] npm installed and verified (`npm --version`)
- [ ] PostgreSQL installed and verified (`psql --version`)
- [ ] PostgreSQL service running
- [ ] Database `vms_db` created
- [ ] User `vms_user` created
- [ ] Can connect to database

---

## 🎯 Next Steps

After successful installation:

1. **Navigate to project:**
   ```powershell
   cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
   ```

2. **Setup Backend:**
   ```powershell
   cd packages\backend
   npm install
   copy .env.example .env
   # Edit .env and update DATABASE_URL if needed
   npm run prisma:generate
   npm run prisma:migrate
   npm run prisma:seed
   npm run start:dev
   ```

3. **Setup Frontend (new terminal):**
   ```powershell
   cd packages\frontend
   npm install
   echo NEXT_PUBLIC_API_URL=http://localhost:3001 > .env.local
   npm run dev
   ```

4. **Access Application:**
   - Frontend: http://localhost:3000
   - Backend: http://localhost:3001
   - API Docs: http://localhost:3001/api

---

## 🔗 Direct Download Links

**Node.js LTS:**
- https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi

**PostgreSQL:**
- https://www.postgresql.org/download/windows/
- Direct installer: https://www.enterprisedb.com/downloads/postgres-postgresql-downloads

---

## 💡 Alternative: Use Docker (Easier)

If you prefer not to install PostgreSQL directly, you can use Docker:

1. Install Docker Desktop: https://www.docker.com/products/docker-desktop
2. Docker Compose will handle PostgreSQL automatically
3. Still need Node.js for development

Good luck with the installation! 🚀

