import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "@/components/status-badge";
import { ContractFormDialog } from "@/components/contract-form-dialog";
import { EstimateExtractorDialog } from "@/components/estimate-extractor-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Contract, Vendor } from "@shared/schema";

export default function Contracts() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();

  const { data: contracts, isLoading: contractsLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const { data: vendors } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const handleItemsExtracted = (items: any[]) => {
    toast({
      title: "Items extracted",
      description: `Extracted ${items.length} item(s). You can now create contracts based on these items.`,
    });
  };

  const getVendorName = (vendorId: string) => {
    return vendors?.find((v) => v.id === vendorId)?.name || "Unknown Vendor";
  };

  const getDaysUntilExpiry = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  };

  const filteredContracts = contracts?.filter((contract) => {
    const vendorName = getVendorName(contract.vendorId);
    const matchesSearch = 
      contract.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vendorName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || contract.status === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Contracts</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage vendor contracts and track renewals
            </p>
          </div>
          <div className="flex gap-2">
            <EstimateExtractorDialog onItemsExtracted={handleItemsExtracted} />
            <ContractFormDialog />
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search contracts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-contracts"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger data-testid="select-filter-status">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="renewed">Renewed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Contracts Table */}
        <Card>
          <CardContent className="p-0">
            {contractsLoading ? (
              <div className="p-6 space-y-4">
                <Skeleton className="h-16" />
                <Skeleton className="h-16" />
                <Skeleton className="h-16" />
              </div>
            ) : filteredContracts.length === 0 ? (
              <div className="text-center py-12 px-6">
                <p className="text-muted-foreground">
                  {searchTerm || statusFilter !== "all"
                    ? "No contracts match your filters"
                    : "No contracts yet. Add your first contract to get started."}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted/50 border-b border-border">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Contract Name
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Vendor
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Value
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Start Date
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        End Date
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredContracts.map((contract) => {
                      const daysLeft = getDaysUntilExpiry(contract.endDate);
                      const isExpiringSoon = daysLeft <= 90 && daysLeft >= 0;
                      
                      return (
                        <tr
                          key={contract.id}
                          className="hover-elevate"
                          data-testid={`contract-row-${contract.id}`}
                        >
                          <td className="px-6 py-4">
                            <div>
                              <p className="font-medium text-foreground">{contract.name}</p>
                              {contract.renewalStatus && (
                                <p className="text-sm text-muted-foreground mt-0.5 capitalize">
                                  {contract.renewalStatus.replace("-", " ")}
                                </p>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-foreground">
                              {getVendorName(contract.vendorId)}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm font-medium text-foreground">
                              ${parseFloat(contract.value).toLocaleString()}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Calendar className="h-3.5 w-3.5" />
                              {new Date(contract.startDate).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Calendar className="h-3.5 w-3.5" />
                                {new Date(contract.endDate).toLocaleDateString()}
                              </div>
                              {isExpiringSoon && contract.status === "active" && (
                                <p className={`text-xs mt-1 font-medium ${
                                  daysLeft <= 30 ? "text-destructive" : "text-chart-4"
                                }`}>
                                  {daysLeft}d remaining
                                </p>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <StatusBadge status={contract.status} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results count */}
        {!contractsLoading && filteredContracts.length > 0 && (
          <div className="mt-4 text-sm text-muted-foreground text-center">
            Showing {filteredContracts.length} of {contracts?.length || 0} contracts
          </div>
        )}
      </div>
    </div>
  );
}
