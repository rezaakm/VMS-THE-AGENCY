import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Search, Star, Eye, Mail, Phone, ArrowUp, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/status-badge";
import { VendorFormDialog } from "@/components/vendor-form-dialog";
import { AISearchBar } from "@/components/ai-search-bar";
import { Skeleton } from "@/components/ui/skeleton";
import type { Vendor } from "@shared/schema";

export default function Vendors() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [aiFilters, setAIFilters] = useState<any>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data: vendors, isLoading } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const categories = vendors
    ? Array.from(new Set(vendors.map((v) => v.category))).sort()
    : [];

  // Handle scroll to show/hide scroll-to-top button
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      setShowScrollTop(container.scrollTop > 300);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    containerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const clearAllFilters = () => {
    setSearchTerm("");
    setCategoryFilter("all");
    setStatusFilter("all");
    setAIFilters(null);
  };

  const hasActiveFilters = searchTerm || categoryFilter !== "all" || statusFilter !== "all" || aiFilters;

  const handleAIFiltersApplied = (filters: any) => {
    setAIFilters(filters);
    
    // Reset manual filters first
    setSearchTerm("");
    setCategoryFilter("all");
    setStatusFilter("all");
    
    // Apply AI-derived filters
    if (filters.category) {
      setCategoryFilter(filters.category);
    }
    if (filters.vendor) {
      setSearchTerm(filters.vendor);
    } else if (filters.keywords && filters.keywords.length > 0) {
      // Only use keywords for search if they're not status-related
      const nonStatusKeywords = filters.keywords.filter((k: string) => 
        !["active", "inactive", "pending"].includes(k.toLowerCase())
      );
      if (nonStatusKeywords.length > 0) {
        setSearchTerm(nonStatusKeywords.join(" "));
      }
    }
  };

  let filteredVendors = vendors?.filter((vendor) => {
    let matches = true;

    // Text search (name, category, or AI keywords)
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      const matchesSearch = vendor.name.toLowerCase().includes(search) ||
        vendor.category.toLowerCase().includes(search);
      matches = matches && matchesSearch;
    }

    // Category filter
    if (categoryFilter !== "all") {
      matches = matches && vendor.category === categoryFilter;
    }

    // Status filter
    if (statusFilter !== "all") {
      matches = matches && vendor.status === statusFilter;
    }

    // AI-specific filters
    if (aiFilters) {
      // Vendor name filter
      if (aiFilters.vendor) {
        matches = matches && vendor.name.toLowerCase().includes(aiFilters.vendor.toLowerCase());
      }

      // Exclude terms
      if (aiFilters.exclude_terms && aiFilters.exclude_terms.length > 0) {
        const hasExcluded = aiFilters.exclude_terms.some((term: string) =>
          vendor.name.toLowerCase().includes(term.toLowerCase()) ||
          vendor.category.toLowerCase().includes(term.toLowerCase())
        );
        matches = matches && !hasExcluded;
      }
    }

    return matches;
  }) || [];

  // Apply AI sorting if present
  if (aiFilters?.sort && aiFilters.sort.length > 0) {
    const sortField = aiFilters.sort[0];
    filteredVendors = [...filteredVendors].sort((a, b) => {
      let aVal: any = a[sortField.field as keyof Vendor];
      let bVal: any = b[sortField.field as keyof Vendor];

      // Handle different data types
      if (typeof aVal === "string") {
        aVal = aVal.toLowerCase();
        bVal = bVal?.toLowerCase() || "";
      }

      if (aVal < bVal) return sortField.dir === "asc" ? -1 : 1;
      if (aVal > bVal) return sortField.dir === "asc" ? 1 : -1;
      return 0;
    });
  }

  // Apply AI limit if present
  if (aiFilters?.limit && aiFilters.limit < filteredVendors.length) {
    filteredVendors = filteredVendors.slice(0, aiFilters.limit);
  }

  return (
    <div ref={containerRef} className="flex-1 overflow-auto relative">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 md:mb-8 gap-4">
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Vendors</h1>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">
              Manage your vendor relationships and contacts
            </p>
          </div>
          <div className="shrink-0">
            <VendorFormDialog />
          </div>
        </div>

        {/* AI Search */}
        <Card className="mb-4">
          <CardContent className="p-4 md:pt-6">
            <AISearchBar
              onFiltersApplied={handleAIFiltersApplied}
              placeholder="Try: 'Show active vendors'"
            />
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4 md:pt-6">
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search vendors..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-vendors"
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger data-testid="select-filter-category">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger data-testid="select-filter-status">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {hasActiveFilters && (
                <div className="flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearAllFilters}
                    data-testid="button-clear-filters"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Clear All Filters
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Vendors Table */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                <Skeleton className="h-16" />
                <Skeleton className="h-16" />
                <Skeleton className="h-16" />
              </div>
            ) : filteredVendors.length === 0 ? (
              <div className="text-center py-12 px-6">
                <p className="text-muted-foreground">
                  {searchTerm || categoryFilter !== "all" || statusFilter !== "all"
                    ? "No vendors match your filters"
                    : "No vendors yet. Add your first vendor to get started."}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto overflow-y-auto max-h-[600px]">
                <table className="w-full min-w-[700px]">
                  <thead className="bg-muted/50 border-b border-border sticky top-0 z-10">
                    <tr>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Vendor Name
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Contact
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Rating
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredVendors.map((vendor) => (
                      <tr
                        key={vendor.id}
                        className="hover-elevate"
                        data-testid={`vendor-row-${vendor.id}`}
                      >
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <div>
                            <p className="text-xs md:text-sm font-medium text-foreground">{vendor.name}</p>
                            {vendor.contactPerson && (
                              <p className="text-xs md:text-sm text-muted-foreground mt-0.5">
                                {vendor.contactPerson}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <span className="text-xs md:text-sm text-foreground">{vendor.category}</span>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <div className="space-y-1">
                            {vendor.email && (
                              <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                                <Mail className="h-3 w-3 md:h-3.5 md:w-3.5 shrink-0" />
                                <span className="truncate max-w-[150px] md:max-w-[200px]">{vendor.email}</span>
                              </div>
                            )}
                            {vendor.phone && (
                              <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                                <Phone className="h-3 w-3 md:h-3.5 md:w-3.5 shrink-0" />
                                <span>{vendor.phone}</span>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 md:h-4 md:w-4 fill-chart-4 text-chart-4" />
                            <span className="text-xs md:text-sm font-medium">
                              {vendor.rating || 0}/5
                            </span>
                          </div>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <StatusBadge status={vendor.status} />
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <Link href={`/vendors/${vendor.id}`}>
                            <Button variant="ghost" size="sm" data-testid={`button-view-${vendor.id}`}>
                              <Eye className="h-4 w-4 md:mr-1" />
                              <span className="hidden md:inline">View</span>
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results count */}
        {!isLoading && filteredVendors.length > 0 && (
          <div className="mt-4 text-xs md:text-sm text-muted-foreground text-center">
            Showing {filteredVendors.length} of {vendors?.length || 0} vendors
          </div>
        )}
      </div>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          size="icon"
          className="fixed bottom-6 right-6 h-12 w-12 rounded-full shadow-lg z-50"
          data-testid="button-scroll-top"
        >
          <ArrowUp className="h-5 w-5" />
        </Button>
      )}
    </div>
  );
}
