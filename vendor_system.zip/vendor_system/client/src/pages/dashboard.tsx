import { useQuery } from "@tanstack/react-query";
import { Building2, FileText, TrendingUp, AlertCircle } from "lucide-react";
import { MetricCard } from "@/components/metric-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/status-badge";
import { VendorFormDialog } from "@/components/vendor-form-dialog";
import { ContractFormDialog } from "@/components/contract-form-dialog";
import { VendorCostTrendChart } from "@/components/VendorCostTrendChart";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Vendor, Contract } from "@shared/schema";

export default function Dashboard() {
  const { data: vendors, isLoading: vendorsLoading } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const { data: contracts, isLoading: contractsLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const activeVendors = vendors?.filter((v) => v.status === "active").length || 0;
  const activeContracts = contracts?.filter((c) => c.status === "active").length || 0;
  
  const avgRating = vendors && vendors.length > 0
    ? (vendors.reduce((sum, v) => sum + (v.rating || 0), 0) / vendors.length).toFixed(1)
    : "0.0";

  const expiringContracts = contracts?.filter((c) => {
    if (c.status !== "active") return false;
    const endDate = new Date(c.endDate);
    const today = new Date();
    const daysUntilExpiry = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 90 && daysUntilExpiry >= 0;
  }) || [];

  const recentVendors = vendors?.slice(0, 5) || [];

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 md:mb-8 gap-4">
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Dashboard</h1>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">
              Overview of your vendor relationships and contracts
            </p>
          </div>
          <div className="flex gap-2 shrink-0">
            <VendorFormDialog />
            <ContractFormDialog />
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
          {vendorsLoading ? (
            <>
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </>
          ) : (
            <>
              <MetricCard
                title="Total Vendors"
                value={vendors?.length || 0}
                icon={Building2}
                trend={{
                  value: `${activeVendors} active`,
                  isPositive: true,
                }}
              />
              <MetricCard
                title="Active Contracts"
                value={activeContracts}
                icon={FileText}
                trend={{
                  value: `${expiringContracts.length} expiring soon`,
                  isPositive: expiringContracts.length === 0,
                }}
              />
              <MetricCard
                title="Avg Performance"
                value={avgRating}
                icon={TrendingUp}
                trend={{
                  value: "Out of 5.0",
                  isPositive: parseFloat(avgRating) >= 3.5,
                }}
              />
            </>
          )}
        </div>

        {/* Vendor Cost Trend Chart */}
        <div className="mb-6 md:mb-8">
          <VendorCostTrendChart />
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          {/* Expiring Contracts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-chart-4" />
                Upcoming Renewals
              </CardTitle>
            </CardHeader>
            <CardContent>
              {contractsLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                </div>
              ) : expiringContracts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <AlertCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No contracts expiring in the next 90 days</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {expiringContracts.slice(0, 5).map((contract) => {
                    const endDate = new Date(contract.endDate);
                    const today = new Date();
                    const daysLeft = Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                    
                    return (
                      <div
                        key={contract.id}
                        className="flex items-center justify-between p-3 rounded-md border border-card-border hover-elevate"
                        data-testid={`contract-${contract.id}`}
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{contract.name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Expires: {new Date(contract.endDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <span className={`text-xs font-medium ${
                            daysLeft <= 30 ? "text-destructive" : "text-chart-4"
                          }`}>
                            {daysLeft}d left
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Vendors */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Recent Vendors
                </span>
                <Link href="/vendors" className="text-sm text-primary hover:underline" data-testid="link-view-all-vendors">
                  View All
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {vendorsLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                </div>
              ) : recentVendors.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No vendors yet</p>
                  <p className="text-xs mt-1">Add your first vendor to get started</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentVendors.map((vendor) => (
                    <Link
                      key={vendor.id}
                      href={`/vendors/${vendor.id}`}
                      data-testid={`vendor-${vendor.id}`}
                    >
                      <div className="flex items-center justify-between p-3 rounded-md border border-card-border hover-elevate">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{vendor.name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{vendor.category}</p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <StatusBadge status={vendor.status} />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
