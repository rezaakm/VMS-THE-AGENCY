import { useEffect } from "react";
import { useLocation } from "wouter";
import { Building2, FileSpreadsheet, Sparkles } from "lucide-react";
import { SiGoogle } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/hooks/useAuth";

export default function Login() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();
  
  // Get error from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');

  // Redirect if already authenticated
  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation('/dashboard');
    }
  }, [isAuthenticated, isLoading, setLocation]);

  const handleGoogleSignIn = () => {
    window.location.href = '/api/login';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-primary/10 mb-4">
            <Building2 className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Vendor Management System
          </h1>
          <p className="text-muted-foreground">
            Streamline vendor relationships, track contracts, and search cost sheets with AI-powered insights
          </p>
        </div>

        {/* Sign In Card */}
        <Card className="mb-6">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Sign In</CardTitle>
            <CardDescription className="text-center">
              Sign in with your The Agency Oman Google account to access the vendor management system
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error === 'unauthorized_email' && (
              <Alert variant="destructive" data-testid="alert-unauthorized">
                <AlertDescription>
                  Only @theagencyoman.com email addresses are authorized to access this system.
                </AlertDescription>
              </Alert>
            )}
            
            <Button
              onClick={handleGoogleSignIn}
              className="w-full"
              size="lg"
              data-testid="button-google-signin"
            >
              <SiGoogle className="mr-2 h-5 w-5" />
              Sign in with Google
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Only @theagencyoman.com email addresses are authorized
            </p>
          </CardContent>
        </Card>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 gap-4">
          <Card className="bg-card/50">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-sm mb-1">Vendor Management</h3>
                <p className="text-xs text-muted-foreground">
                  Track 100+ vendor relationships with contacts, ratings, and performance metrics all in one place
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                <FileSpreadsheet className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-sm mb-1">Cost Sheet Search</h3>
                <p className="text-xs text-muted-foreground">
                  Search across 1000+ Excel cost sheets from Google Drive to find historical pricing and create estimates
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50">
            <CardContent className="p-4 flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-sm mb-1">AI-Powered Search</h3>
                <p className="text-xs text-muted-foreground">
                  Use natural language queries to find vendors, filter by category, and extract data from client emails
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
