import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Building2, Mail, Phone, Globe, MapPin, Star, FileText, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/status-badge";
import { ContractFormDialog } from "@/components/contract-form-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import type { Vendor, Contract, Contact } from "@shared/schema";

export default function VendorDetail() {
  const { id } = useParams<{ id: string }>();

  const { data: vendor, isLoading: vendorLoading } = useQuery<Vendor>({
    queryKey: [`/api/vendors/${id}`],
  });

  const { data: contracts, isLoading: contractsLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const { data: contacts, isLoading: contactsLoading } = useQuery<Contact[]>({
    queryKey: ["/api/contacts"],
  });

  const vendorContracts = contracts?.filter((c) => c.vendorId === id) || [];
  const vendorContacts = contacts?.filter((c) => c.vendorId === id) || [];
  const activeContracts = vendorContracts.filter((c) => c.status === "active").length;
  const totalContractValue = vendorContracts.reduce(
    (sum, c) => sum + parseFloat(c.value || "0"),
    0
  );

  if (vendorLoading) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <Skeleton className="h-8 w-48 mb-6" />
          <Skeleton className="h-64 mb-6" />
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  if (!vendor) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center py-12">
            <Building2 className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h2 className="text-2xl font-bold mb-2">Vendor Not Found</h2>
            <p className="text-muted-foreground mb-6">The vendor you're looking for doesn't exist.</p>
            <Link href="/vendors">
              <Button>Back to Vendors</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <Link href="/vendors">
            <Button variant="ghost" size="sm" className="mb-4" data-testid="button-back-vendors">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Vendors
            </Button>
          </Link>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="h-16 w-16 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Building2 className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground" data-testid="text-vendor-name">
                  {vendor.name}
                </h1>
                <div className="flex items-center gap-3 mt-2">
                  <StatusBadge status={vendor.status} />
                  <span className="text-sm text-muted-foreground">{vendor.category}</span>
                  {vendor.rating > 0 && (
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-chart-4 text-chart-4" />
                      <span className="text-sm font-medium">{vendor.rating}/5</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <ContractFormDialog preselectedVendorId={id} />
          </div>
        </div>

        {/* Quick Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Contracts</p>
                  <p className="text-2xl font-bold mt-1">{activeContracts}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Value</p>
                  <p className="text-2xl font-bold mt-1">
                    ${totalContractValue.toLocaleString()}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Contacts</p>
                  <p className="text-2xl font-bold mt-1">{vendorContacts.length}</p>
                </div>
                <Users className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="contracts" data-testid="tab-contracts">
              Contracts ({vendorContracts.length})
            </TabsTrigger>
            <TabsTrigger value="contacts" data-testid="tab-contacts">
              Contacts ({vendorContacts.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Company Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {vendor.contactPerson && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Contact Person</p>
                      <p className="text-base mt-1">{vendor.contactPerson}</p>
                    </div>
                  )}
                  {vendor.email && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Email</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <a href={`mailto:${vendor.email}`} className="text-base text-primary hover:underline">
                          {vendor.email}
                        </a>
                      </div>
                    </div>
                  )}
                  {vendor.phone && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Phone</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <a href={`tel:${vendor.phone}`} className="text-base text-primary hover:underline">
                          {vendor.phone}
                        </a>
                      </div>
                    </div>
                  )}
                  {vendor.website && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Website</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <a
                          href={vendor.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-base text-primary hover:underline"
                        >
                          {vendor.website}
                        </a>
                      </div>
                    </div>
                  )}
                  {vendor.address && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Address</p>
                      <div className="flex items-start gap-2 mt-1">
                        <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <p className="text-base">{vendor.address}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Notes */}
              <Card>
                <CardHeader>
                  <CardTitle>Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  {vendor.notes ? (
                    <p className="text-sm text-foreground whitespace-pre-wrap">{vendor.notes}</p>
                  ) : (
                    <p className="text-sm text-muted-foreground">No notes available</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="contracts">
            <Card>
              <CardHeader>
                <CardTitle>Contracts</CardTitle>
              </CardHeader>
              <CardContent>
                {contractsLoading ? (
                  <div className="space-y-3">
                    <Skeleton className="h-20" />
                    <Skeleton className="h-20" />
                  </div>
                ) : vendorContracts.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-50" />
                    <p className="text-muted-foreground">No contracts yet</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Create a contract to track agreements with this vendor
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {vendorContracts.map((contract) => (
                      <div
                        key={contract.id}
                        className="p-4 rounded-md border border-card-border hover-elevate"
                        data-testid={`contract-${contract.id}`}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-semibold text-base">{contract.name}</h4>
                            <div className="grid grid-cols-2 gap-3 mt-3 text-sm">
                              <div>
                                <span className="text-muted-foreground">Value:</span>{" "}
                                <span className="font-medium">
                                  ${parseFloat(contract.value).toLocaleString()}
                                </span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Status:</span>{" "}
                                <StatusBadge status={contract.status} className="ml-1" />
                              </div>
                              <div>
                                <span className="text-muted-foreground">Start:</span>{" "}
                                <span className="font-medium">
                                  {new Date(contract.startDate).toLocaleDateString()}
                                </span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">End:</span>{" "}
                                <span className="font-medium">
                                  {new Date(contract.endDate).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts">
            <Card>
              <CardHeader>
                <CardTitle>Contacts</CardTitle>
              </CardHeader>
              <CardContent>
                {contactsLoading ? (
                  <div className="space-y-3">
                    <Skeleton className="h-20" />
                    <Skeleton className="h-20" />
                  </div>
                ) : vendorContacts.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-50" />
                    <p className="text-muted-foreground">No contacts yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {vendorContacts.map((contact) => (
                      <div
                        key={contact.id}
                        className="p-4 rounded-md border border-card-border hover-elevate"
                        data-testid={`contact-${contact.id}`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold text-base">{contact.name}</h4>
                            {contact.title && (
                              <p className="text-sm text-muted-foreground mt-0.5">
                                {contact.title}
                              </p>
                            )}
                            <div className="flex flex-col gap-1 mt-3">
                              <div className="flex items-center gap-2 text-sm">
                                <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                                <a href={`mailto:${contact.email}`} className="text-primary hover:underline">
                                  {contact.email}
                                </a>
                              </div>
                              {contact.phone && (
                                <div className="flex items-center gap-2 text-sm">
                                  <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                                  <a href={`tel:${contact.phone}`} className="text-primary hover:underline">
                                    {contact.phone}
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                          {contact.isPrimary === 1 && (
                            <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded">
                              Primary
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
