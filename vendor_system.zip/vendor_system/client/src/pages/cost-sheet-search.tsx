import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, RefreshCw, CheckCircle2, Upload, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CreateEstimateDialog } from "@/components/create-estimate-dialog";
import type { CostSheetItem, CostSheet } from "@shared/schema";

interface EnrichedItem extends CostSheetItem {
  costSheet?: CostSheet;
}

interface SyncResult {
  success: boolean;
  filesProcessed: number;
  filesSkipped: number;
  rowsInserted: number;
  rowsSkipped: number;
  errors: string[];
}

export default function CostSheetSearch() {
  const [searchTerm, setSearchTerm] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");
  const [minPriceFilter, setMinPriceFilter] = useState("");
  const [maxPriceFilter, setMaxPriceFilter] = useState("");
  const [jobNumberFilter, setJobNumberFilter] = useState("");
  const [clientFilter, setClientFilter] = useState("");
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [estimateDialogOpen, setEstimateDialogOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: items = [], isLoading } = useQuery<EnrichedItem[]>({
    queryKey: ["/api/cost-sheet-items"],
    enabled: false,
  });

  const { data: searchResults, isLoading: isSearching, refetch: performSearch } = useQuery<EnrichedItem[]>({
    queryKey: ["/api/cost-sheet-items/search", searchTerm, vendorFilter, minPriceFilter, maxPriceFilter, jobNumberFilter, clientFilter],
    queryFn: async () => {
      if (!searchTerm.trim()) return [];
      
      // Build query params
      const params = new URLSearchParams();
      params.append('q', searchTerm);
      if (vendorFilter.trim()) params.append('vendor', vendorFilter);
      if (minPriceFilter.trim()) params.append('minPrice', minPriceFilter);
      if (maxPriceFilter.trim()) params.append('maxPrice', maxPriceFilter);
      if (jobNumberFilter.trim()) params.append('jobNumber', jobNumberFilter);
      if (clientFilter.trim()) params.append('client', clientFilter);
      
      const response = await fetch(`/api/cost-sheet-items/search?${params.toString()}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: false,
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/cost-sheets/sync");
      return await response.json() as SyncResult;
    },
    onSuccess: (result) => {
      toast({
        title: "Sync Complete",
        description: `Processed ${result.filesProcessed} files (${result.filesSkipped} skipped), inserted ${result.rowsInserted} rows (${result.rowsSkipped} skipped)${result.errors.length > 0 ? `. Errors: ${result.errors.length}` : ''}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cost-sheet-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ fileName, fileData }: { fileName: string; fileData: string }) => {
      const response = await apiRequest("POST", "/api/cost-sheets/upload", {
        fileName,
        fileData,
      });
      return await response.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Upload Complete",
        description: `Imported ${result.itemsCreated} items from ${result.costSheet.fileName}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cost-sheet-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (itemId: string) => {
      const response = await apiRequest("DELETE", `/api/cost-sheet-items/${itemId}`);
      if (!response.ok && response.status !== 204) {
        throw new Error("Failed to delete item");
      }
      return itemId;
    },
    onSuccess: (deletedId) => {
      toast({
        title: "Item Deleted",
        description: "Cost sheet item has been removed",
      });
      // Remove from selection if it was selected
      setSelectedItems(prev => {
        const next = new Set(prev);
        next.delete(deletedId);
        return next;
      });
      // Refresh search results
      performSearch();
    },
    onError: (error: Error) => {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const response = await apiRequest("POST", "/api/cost-sheet-items/bulk-delete", { ids });
      return await response.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Items Deleted",
        description: `Removed ${result.deleted} items`,
      });
      setSelectedItems(new Set());
      // Refresh search results
      performSearch();
    },
    onError: (error: Error) => {
      toast({
        title: "Bulk Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      performSearch();
    }
  };

  const handleSync = () => {
    syncMutation.mutate();
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check if it's an Excel file
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast({
        title: "Invalid File",
        description: "Please upload an Excel file (.xlsx or .xls)",
        variant: "destructive",
      });
      return;
    }

    try {
      // Read file as ArrayBuffer then convert to base64
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < uint8Array.byteLength; i++) {
        binary += String.fromCharCode(uint8Array[i]);
      }
      const fileData = btoa(binary);

      // Upload to backend
      uploadMutation.mutate({
        fileName: file.name,
        fileData,
      });

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      toast({
        title: "Error Reading File",
        description: "Failed to read the uploaded file",
        variant: "destructive",
      });
    }
  };

  const toggleItemSelection = (itemId: string) => {
    const newSelection = new Set(selectedItems);
    if (newSelection.has(itemId)) {
      newSelection.delete(itemId);
    } else {
      newSelection.add(itemId);
    }
    setSelectedItems(newSelection);
  };

  const displayItems = searchResults || [];
  
  // Get selected items as full objects for the estimate dialog
  const getSelectedItemsDetails = (): EnrichedItem[] => {
    return displayItems.filter(item => selectedItems.has(item.id));
  };

  const handleEstimateSuccess = () => {
    setSelectedItems(new Set()); // Clear selection after creating estimate
  };

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 md:mb-8 gap-4">
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Cost Sheet Search</h1>
            <p className="text-sm md:text-base text-muted-foreground mt-1 md:mt-2">
              Search across 1000+ historical jobs to find pricing data
            </p>
          </div>
          <div className="flex gap-2 shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              className="hidden"
              data-testid="input-file-upload"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadMutation.isPending}
              data-testid="button-upload"
              className="hidden sm:flex"
            >
              {uploadMutation.isPending ? (
                <>
                  <Upload className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Excel
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadMutation.isPending}
              data-testid="button-upload-mobile"
              className="sm:hidden"
            >
              <Upload className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              onClick={handleSync}
              disabled={syncMutation.isPending}
              data-testid="button-sync"
              className="hidden sm:flex"
            >
              {syncMutation.isPending ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Sync from Drive
                </>
              )}
            </Button>
            <Button
              size="icon"
              onClick={handleSync}
              disabled={syncMutation.isPending}
              data-testid="button-sync-mobile"
              className="sm:hidden"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <Card className="mb-6">
          <CardContent className="p-4 md:p-6">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search for items (e.g., 'backdrop', 'LED')..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search"
                  />
                </div>
                <Button type="submit" disabled={isSearching || !searchTerm.trim()} data-testid="button-search" className="sm:w-auto">
                  {isSearching ? "Searching..." : "Search"}
                </Button>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 md:gap-4 pt-4 border-t">
                <div>
                  <label className="text-xs md:text-sm font-medium text-muted-foreground mb-1.5 md:mb-2 block">
                    Vendor
                  </label>
                  <Input
                    type="text"
                    placeholder="Filter by vendor"
                    value={vendorFilter}
                    onChange={(e) => setVendorFilter(e.target.value)}
                    data-testid="input-vendor-filter"
                  />
                </div>
                <div>
                  <label className="text-xs md:text-sm font-medium text-muted-foreground mb-1.5 md:mb-2 block">
                    Min Price
                  </label>
                  <Input
                    type="number"
                    placeholder="Min price"
                    value={minPriceFilter}
                    onChange={(e) => setMinPriceFilter(e.target.value)}
                    data-testid="input-min-price-filter"
                  />
                </div>
                <div>
                  <label className="text-xs md:text-sm font-medium text-muted-foreground mb-1.5 md:mb-2 block">
                    Max Price
                  </label>
                  <Input
                    type="number"
                    placeholder="Max price"
                    value={maxPriceFilter}
                    onChange={(e) => setMaxPriceFilter(e.target.value)}
                    data-testid="input-max-price-filter"
                  />
                </div>
                <div>
                  <label className="text-xs md:text-sm font-medium text-muted-foreground mb-1.5 md:mb-2 block">
                    Job Number
                  </label>
                  <Input
                    type="text"
                    placeholder="Filter by job #"
                    value={jobNumberFilter}
                    onChange={(e) => setJobNumberFilter(e.target.value)}
                    data-testid="input-job-filter"
                  />
                </div>
                <div>
                  <label className="text-xs md:text-sm font-medium text-muted-foreground mb-1.5 md:mb-2 block">
                    Client
                  </label>
                  <Input
                    type="text"
                    placeholder="Filter by client"
                    value={clientFilter}
                    onChange={(e) => setClientFilter(e.target.value)}
                    data-testid="input-client-filter"
                  />
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Selected Items Banner */}
        {selectedItems.size > 0 && (
          <div className="mb-6 p-4 bg-primary/10 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
              <span className="text-sm md:text-base font-medium">{selectedItems.size} items selected</span>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedItems(new Set())}
                data-testid="button-clear-selection"
              >
                Clear
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => bulkDeleteMutation.mutate(Array.from(selectedItems))}
                disabled={bulkDeleteMutation.isPending}
                data-testid="button-delete-selected"
              >
                {bulkDeleteMutation.isPending ? (
                  <>
                    <Trash2 className="mr-2 h-4 w-4 animate-pulse" />
                    <span className="hidden sm:inline">Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="h-4 w-4 sm:mr-2" />
                    <span className="hidden sm:inline">Delete</span>
                  </>
                )}
              </Button>
              <Button
                size="sm"
                onClick={() => setEstimateDialogOpen(true)}
                data-testid="button-create-estimate"
              >
                <span className="hidden sm:inline">Create Estimate</span>
                <span className="sm:hidden">Estimate</span>
              </Button>
            </div>
          </div>
        )}

        {/* Results */}
        <Card>
          <CardContent className="p-0">
            {isSearching ? (
              <div className="p-6 space-y-3">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : displayItems.length === 0 ? (
              <div className="p-8 md:p-12 text-center text-muted-foreground">
                <Search className="mx-auto h-10 md:h-12 w-10 md:w-12 mb-4 opacity-20" />
                <p className="text-base md:text-lg font-medium">
                  {searchTerm ? "No items found" : "Enter a search term to find items"}
                </p>
                <p className="text-xs md:text-sm mt-2">
                  {searchTerm 
                    ? "Try different keywords or sync new cost sheets from Google Drive"
                    : "Search for items like 'backdrop', 'LED screen', or 'audio equipment'"}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[800px]" data-testid="table-results">
                  <thead className="bg-muted/50 border-b">
                    <tr>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold">
                        <span className="sr-only">Select</span>
                      </th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold">Description</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold">Vendor</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold">Job Info</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">Days</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">Unit Cost</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">Total Cost</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">Unit Price</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">Total Price</th>
                      <th className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-semibold">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {displayItems.map((item) => (
                      <tr
                        key={item.id}
                        className="hover-elevate"
                        data-testid={`row-item-${item.id}`}
                      >
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <input
                            type="checkbox"
                            checked={selectedItems.has(item.id)}
                            onChange={() => toggleItemSelection(item.id)}
                            className="h-4 w-4 rounded border-gray-300"
                            data-testid={`checkbox-item-${item.id}`}
                          />
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <div className="max-w-xs md:max-w-md">
                            <p className="text-xs md:text-sm font-medium text-foreground line-clamp-2">
                              {item.description}
                            </p>
                            {item.itemNumber && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Item #{item.itemNumber}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          <span className="text-xs md:text-sm text-foreground">
                            {item.vendor || "-"}
                          </span>
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4">
                          {item.costSheet ? (
                            <div className="text-xs md:text-sm">
                              <p className="font-medium text-foreground">
                                Job #{item.costSheet.jobNumber}
                              </p>
                              <p className="text-muted-foreground">{item.costSheet.client}</p>
                              <p className="text-xs text-muted-foreground">{item.costSheet.event}</p>
                              {item.costSheet.date && (
                                <p className="text-xs text-muted-foreground mt-1">{item.costSheet.date}</p>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs md:text-sm text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm">
                          {item.days || "-"}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-medium">
                          {item.unitCost || "-"}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-medium">
                          {item.totalCost || "-"}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-medium">
                          {item.unitSellingPrice || "-"}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right text-xs md:text-sm font-medium text-primary">
                          {item.totalSellingPrice || "-"}
                        </td>
                        <td className="px-4 md:px-6 py-3 md:py-4 text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteMutation.mutate(item.id)}
                            disabled={deleteMutation.isPending}
                            data-testid={`button-delete-${item.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Summary */}
        {displayItems.length > 0 && (
          <div className="mt-4 text-xs md:text-sm text-muted-foreground">
            Found {displayItems.length} items matching "{searchTerm}"
          </div>
        )}
      </div>

      {/* Create Estimate Dialog */}
      <CreateEstimateDialog
        open={estimateDialogOpen}
        onOpenChange={setEstimateDialogOpen}
        selectedItems={getSelectedItemsDetails()}
        onSuccess={handleEstimateSuccess}
      />
    </div>
  );
}
