import { useQuery } from "@tanstack/react-query";
import { TrendingUp, TrendingDown, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import type { Vendor } from "@shared/schema";

export default function Performance() {
  const [timeFilter, setTimeFilter] = useState("all");

  const { data: vendors, isLoading } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const activeVendors = vendors?.filter((v) => v.status === "active") || [];
  
  const avgRating = activeVendors.length > 0
    ? (activeVendors.reduce((sum, v) => sum + (v.rating || 0), 0) / activeVendors.length).toFixed(1)
    : "0.0";

  const topPerformers = [...activeVendors]
    .filter((v) => v.rating && v.rating > 0)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, 5);

  const lowPerformers = [...activeVendors]
    .filter((v) => v.rating && v.rating > 0)
    .sort((a, b) => (a.rating || 0) - (b.rating || 0))
    .slice(0, 5);

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Performance Metrics</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Track and analyze vendor performance
            </p>
          </div>
          <Select value={timeFilter} onValueChange={setTimeFilter}>
            <SelectTrigger className="w-[180px]" data-testid="select-time-filter">
              <SelectValue placeholder="Time period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="60">Last 60 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {isLoading ? (
            <>
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </>
          ) : (
            <>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Average Rating</p>
                      <p className="text-3xl font-bold mt-1" data-testid="metric-average-rating">
                        {avgRating}/5
                      </p>
                    </div>
                    <Award className="h-8 w-8 text-chart-4" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Top Performers</p>
                      <p className="text-3xl font-bold mt-1">{topPerformers.length}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-secondary" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Needs Attention</p>
                      <p className="text-3xl font-bold mt-1">{lowPerformers.length}</p>
                    </div>
                    <TrendingDown className="h-8 w-8 text-destructive" />
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {/* Performance Lists */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Performers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-secondary" />
                Top Performers
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                </div>
              ) : topPerformers.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Award className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No rated vendors yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {topPerformers.map((vendor, index) => (
                    <div
                      key={vendor.id}
                      className="flex items-center justify-between p-3 rounded-md border border-card-border hover-elevate"
                      data-testid={`top-performer-${vendor.id}`}
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary/10 text-secondary font-bold text-sm flex-shrink-0">
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{vendor.name}</p>
                          <p className="text-xs text-muted-foreground">{vendor.category}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 ml-4">
                        <Award className="h-4 w-4 text-chart-4" />
                        <span className="font-bold text-sm">{vendor.rating}/5</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Low Performers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5 text-destructive" />
                Needs Attention
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                  <Skeleton className="h-16" />
                </div>
              ) : lowPerformers.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <TrendingDown className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No rated vendors yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {lowPerformers.map((vendor) => (
                    <div
                      key={vendor.id}
                      className="flex items-center justify-between p-3 rounded-md border border-card-border hover-elevate"
                      data-testid={`low-performer-${vendor.id}`}
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{vendor.name}</p>
                        <p className="text-xs text-muted-foreground">{vendor.category}</p>
                      </div>
                      <div className="flex items-center gap-1 ml-4">
                        <Award className="h-4 w-4 text-muted-foreground" />
                        <span className="font-bold text-sm">{vendor.rating}/5</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
