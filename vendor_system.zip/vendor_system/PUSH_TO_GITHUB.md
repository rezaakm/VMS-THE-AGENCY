# Pushing Code to GitHub

The code needs to be pushed to GitHub. Here are the options:

## Option 1: Browser Authentication (Easiest)

When you run `git push`, it will open a browser window asking you to authenticate. Just follow the prompts.

## Option 2: Use Personal Access Token (PAT)

1. Create a Personal Access Token:
   - Go to GitHub.com → Settings → Developer settings → Personal access tokens → Tokens (classic)
   - Generate new token (classic)
   - Give it a name like "VMS Push"
   - Select scope: `repo` (full control of private repositories)
   - Copy the token

2. Push using the token:
   ```bash
   git push https://<YOUR_TOKEN>@github.com/rezaakm/vendor-management-system.git main
   ```

   Or update the remote:
   ```bash
   git remote set-url origin https://<YOUR_TOKEN>@github.com/rezaakm/vendor-management-system.git
   git push -u origin main
   ```

## Option 3: Use SSH (If you have SSH keys set up)

1. Change remote to SSH:
   ```bash
   git remote set-url origin git@github.com:rezaakm/vendor-management-system.git
   ```

2. Push:
   ```bash
   git push -u origin main
   ```

## Quick Push Command

If you want to try the browser authentication again:

```bash
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
git push -u origin main
```

When prompted, complete the authentication in your browser.

