# 🚀 Install Node.js and PostgreSQL Now

## Step 1: Install Node.js

1. **Find the Node.js installer** on your Desktop (looks like: `node-v20.x.x-x64.msi`)

2. **Double-click** the installer to run it

3. **Follow the installation wizard:**
   - Click "Next"
   - Accept the license agreement
   - Keep default installation path
   - ✅ **IMPORTANT:** Make sure "Add to PATH" is checked (should be by default)
   - Click "Install"
   - Wait for installation (1-2 minutes)
   - Click "Finish"

4. **CLOSE and REOPEN PowerShell** (important!)

5. **Verify installation:**
   ```powershell
   node --version
   npm --version
   ```
   You should see version numbers (like v20.11.0 and 10.x.x)

---

## Step 2: Install PostgreSQL

1. **Find the PostgreSQL installer** on your Desktop (looks like: `postgresql-15-x64.exe` or similar)

2. **Double-click** the installer to run it

3. **Follow the installation wizard:**
   - Click "Next"
   - Keep default installation directory: `C:\Program Files\PostgreSQL\15`
   - **Select Components:** Keep all checked (PostgreSQL Server, pgAdmin 4, Stack Builder, Command Line Tools)
   - Keep default data directory
   - **⚠️ SET PASSWORD:** Enter `postgres` (or write down your password!)
   - Keep default port: `5432`
   - Keep default locale
   - Click "Next" through remaining steps
   - Click "Install"
   - Wait for installation (3-5 minutes)
   - Uncheck "Launch Stack Builder" if you don't need it
   - Click "Finish"

4. **CLOSE and REOPEN PowerShell** (important!)

5. **Verify installation:**
   ```powershell
   psql --version
   ```
   You should see version information

---

## Step 3: Setup Database

After both are installed, create the VMS database:

**Option A: Using the setup script (Easiest)**
```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
powershell -ExecutionPolicy Bypass -File .\setup-database.ps1
```
(When prompted, enter password: `postgres` or your PostgreSQL password)

**Option B: Manual setup**
1. Open **pgAdmin 4** from Start Menu
2. Enter password: `postgres` (or your password)
3. Right-click "Databases" → Create → Database
4. Name: `vms_db`
5. Click "Save"

---

## Step 4: Verify Everything

Run this command to check everything:
```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
powershell -ExecutionPolicy Bypass -File .\verify-installation.ps1
```

---

## Step 5: Setup VMS Project

Once everything is installed:

```powershell
# 1. Setup Backend
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\backend
npm install
copy .env.example .env
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run start:dev

# 2. Setup Frontend (in a NEW PowerShell window)
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\frontend
npm install
echo NEXT_PUBLIC_API_URL=http://localhost:3001 > .env.local
npm run dev
```

---

## ✅ Installation Checklist

- [ ] Node.js installer run successfully
- [ ] PowerShell restarted after Node.js install
- [ ] `node --version` works
- [ ] PostgreSQL installer run successfully
- [ ] PostgreSQL password set (remember it!)
- [ ] PowerShell restarted after PostgreSQL install
- [ ] `psql --version` works
- [ ] Database `vms_db` created
- [ ] Ready to setup VMS project!

---

**Need Help?** See `INSTALL_STEPS.txt` or `INSTALL_PREREQUISITES.md` for detailed instructions.

