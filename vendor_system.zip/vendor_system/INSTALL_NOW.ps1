# Automated Installation Helper for Node.js and PostgreSQL
# This script will open download pages and guide you through installation

Write-Host "🚀 Vendor Management System - Installation Helper" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host ""

# Check current status
Write-Host "Checking current installation status..." -ForegroundColor Yellow
Write-Host ""

$nodeInstalled = $false
$postgresInstalled = $false

# Check Node.js
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $nodeInstalled = $true
        Write-Host "✅ Node.js is installed: $nodeVersion" -ForegroundColor Green
    }
} catch {
    Write-Host "❌ Node.js is NOT installed" -ForegroundColor Red
}

# Check PostgreSQL
try {
    $psqlVersion = psql --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $postgresInstalled = $true
        Write-Host "✅ PostgreSQL is installed: $psqlVersion" -ForegroundColor Green
    }
} catch {
    Write-Host "❌ PostgreSQL is NOT installed" -ForegroundColor Red
}

Write-Host ""
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host ""

if ($nodeInstalled -and $postgresInstalled) {
    Write-Host "🎉 Both Node.js and PostgreSQL are already installed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "You can proceed with setting up the VMS project." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "  1. cd packages\backend" -ForegroundColor White
    Write-Host "  2. npm install" -ForegroundColor White
    Write-Host "  3. npm run prisma:generate" -ForegroundColor White
    exit 0
}

# Installation needed
Write-Host "📦 Installation Required" -ForegroundColor Yellow
Write-Host ""

if (-not $nodeInstalled) {
    Write-Host "📥 Installing Node.js..." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Opening Node.js download page..." -ForegroundColor Gray
    
    # Open Node.js download page
    Start-Process "https://nodejs.org/"
    
    Write-Host ""
    Write-Host "Installation Instructions:" -ForegroundColor Yellow
    Write-Host "  1. Download the LTS version (Long Term Support)" -ForegroundColor White
    Write-Host "  2. Run the downloaded .msi installer" -ForegroundColor White
    Write-Host "  3. Click 'Next' through the installation wizard" -ForegroundColor White
    Write-Host "  4. Keep default options (including 'Add to PATH')" -ForegroundColor White
    Write-Host "  5. Click 'Install' and wait for completion" -ForegroundColor White
    Write-Host "  6. Restart PowerShell after installation" -ForegroundColor White
    Write-Host ""
    Write-Host "Direct download link:" -ForegroundColor Yellow
    Write-Host "  https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi" -ForegroundColor Cyan
    Write-Host ""
    
    $continue = Read-Host "Press Enter after you have completed Node.js installation (or type 'skip' to skip)"
    
    if ($continue -ne "skip") {
        Write-Host ""
        Write-Host "Verifying Node.js installation..." -ForegroundColor Yellow
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        try {
            $nodeCheck = node --version 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✅ Node.js installed successfully: $nodeCheck" -ForegroundColor Green
                Write-Host "✅ npm version: $(npm --version)" -ForegroundColor Green
            } else {
                Write-Host "⚠️  Node.js may not be in PATH yet. Please restart PowerShell and run this script again." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "⚠️  Please restart PowerShell after installation for changes to take effect." -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
    Write-Host "=" * 60 -ForegroundColor Cyan
    Write-Host ""
}

if (-not $postgresInstalled) {
    Write-Host "📥 Installing PostgreSQL..." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Opening PostgreSQL download page..." -ForegroundColor Gray
    
    # Open PostgreSQL download page
    Start-Process "https://www.postgresql.org/download/windows/"
    
    Write-Host ""
    Write-Host "Installation Instructions:" -ForegroundColor Yellow
    Write-Host "  1. Click 'Download the installer'" -ForegroundColor White
    Write-Host "  2. Download PostgreSQL 15 or 16 (latest version)" -ForegroundColor White
    Write-Host "  3. Run the downloaded installer" -ForegroundColor White
    Write-Host "  4. Follow these settings:" -ForegroundColor White
    Write-Host "     - Installation directory: Keep default" -ForegroundColor Gray
    Write-Host "     - Components: Keep all checked" -ForegroundColor Gray
    Write-Host "     - Data directory: Keep default" -ForegroundColor Gray
    Write-Host "     - Password: Set to 'postgres' (or remember your password!)" -ForegroundColor Gray
    Write-Host "     - Port: Keep default (5432)" -ForegroundColor Gray
    Write-Host "  5. Complete the installation" -ForegroundColor White
    Write-Host "  6. You may need to restart PowerShell after installation" -ForegroundColor White
    Write-Host ""
    Write-Host "Alternative: Direct installer download" -ForegroundColor Yellow
    Write-Host "  Visit: https://www.enterprisedb.com/downloads/postgres-postgresql-downloads" -ForegroundColor Cyan
    Write-Host ""
    
    $continue = Read-Host "Press Enter after you have completed PostgreSQL installation (or type 'skip' to skip)"
    
    if ($continue -ne "skip") {
        Write-Host ""
        Write-Host "Verifying PostgreSQL installation..." -ForegroundColor Yellow
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        try {
            $psqlCheck = psql --version 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✅ PostgreSQL installed successfully: $psqlCheck" -ForegroundColor Green
                
                Write-Host ""
                Write-Host "Would you like to set up the VMS database now? (Y/N)" -ForegroundColor Yellow
                $setupDb = Read-Host
                
                if ($setupDb -eq "Y" -or $setupDb -eq "y") {
                    Write-Host ""
                    Write-Host "Running database setup script..." -ForegroundColor Cyan
                    & "$PSScriptRoot\setup-database.ps1"
                }
            } else {
                Write-Host "⚠️  PostgreSQL may not be in PATH yet. Please restart PowerShell." -ForegroundColor Yellow
                Write-Host "   Or add to PATH manually: C:\Program Files\PostgreSQL\15\bin" -ForegroundColor Gray
            }
        } catch {
            Write-Host "⚠️  Please restart PowerShell after installation for changes to take effect." -ForegroundColor Yellow
        }
    }
}

Write-Host ""
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host ""
Write-Host "✅ Installation process complete!" -ForegroundColor Green
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "  1. If you just installed Node.js or PostgreSQL, RESTART PowerShell" -ForegroundColor White
Write-Host "  2. Verify installation:" -ForegroundColor White
Write-Host "     node --version" -ForegroundColor Gray
Write-Host "     psql --version" -ForegroundColor Gray
Write-Host "  3. Run database setup (if not done): .\setup-database.ps1" -ForegroundColor White
Write-Host "  4. Follow QUICK_START.md to run the VMS project" -ForegroundColor White
Write-Host ""
Write-Host "For detailed instructions, see: INSTALL_PREREQUISITES.md" -ForegroundColor Gray
Write-Host ""

