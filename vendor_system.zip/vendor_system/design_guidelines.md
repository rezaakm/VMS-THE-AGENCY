# Vendor Management Application - Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Salesforce CRM + HubSpot) with Design System Foundation

This enterprise B2B application prioritizes data clarity, efficient workflows, and professional credibility. Drawing from Salesforce's robust data presentation and HubSpot's clean contact management, we'll create an information-dense yet scannable interface optimized for vendor relationship management.

---

## Color System (User-Specified)

- **Primary:** #2563EB (Professional Blue) - CTAs, active states, primary actions
- **Secondary:** #059669 (Success Green) - positive metrics, active vendors, confirmations
- **Background:** #F8FAFC (Light Grey) - page background, card containers
- **Text:** #1E293B (Dark Slate) - primary text, headings
- **Accent:** #DC2626 (Alert Red) - warnings, inactive vendors, urgent actions
- **Neutral:** #64748B (Medium Grey) - secondary text, borders, subtle UI elements

---

## Typography

**Font Families:** Inter (primary) with Open Sans (fallback) via Google Fonts CDN

**Type Scale:**
- Hero/Page Titles: text-3xl font-bold (30px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-xl font-semibold (20px)
- Body Text: text-base font-normal (16px)
- Small Text/Labels: text-sm font-medium (14px)
- Table Headers: text-sm font-semibold uppercase tracking-wide
- Metadata: text-xs font-normal (12px)

---

## Layout System

**Spacing Units:** Tailwind units of 2, 4, 6, and 8 for consistent rhythm
- Component padding: p-6
- Card spacing: gap-6
- Section margins: mb-8
- Tight spacing: gap-2 or gap-4
- Container padding: px-6 py-8

**Grid System:**
- Dashboard: 3-column metric cards (grid-cols-1 md:grid-cols-3)
- Vendor listings: Single column tables on mobile, full-width on desktop
- Detail views: 2-column layout (8fr main content, 4fr sidebar) on desktop

**Container Widths:**
- Main application: max-w-7xl mx-auto
- Data tables: Full width within container
- Forms/modals: max-w-2xl

---

## Component Library

### Navigation
**Top Navigation Bar:**
- Fixed header with app logo, global search, and user menu
- Height: h-16
- Background: white with subtle shadow (shadow-sm)
- Logo left-aligned, search center, actions right-aligned

**Sidebar Navigation:**
- Width: w-64 on desktop, collapsible on mobile
- Background: white with border-r
- Active states: bg-blue-50 with border-l-4 border-primary
- Icons: Heroicons outline style, w-5 h-5

### Data Tables
**Primary Table Style (Salesforce-inspired):**
- Alternating row backgrounds: even:bg-gray-50
- Row hover: hover:bg-blue-50 transition
- Header: bg-gray-100 with sticky positioning
- Cell padding: px-6 py-4
- Borders: border-b border-gray-200
- Status badges inline with cell content
- Action buttons right-aligned in last column

**Table Features:**
- Sortable columns with arrow indicators
- Checkbox selection for bulk actions
- Row click for detail navigation
- Pagination controls at bottom

### Cards
**Vendor Summary Cards:**
- Background: bg-white
- Border: border border-gray-200
- Radius: rounded-lg
- Shadow: shadow-sm hover:shadow-md transition
- Padding: p-6
- Card header with vendor name and status badge
- Grid layout for key metrics within card

**Metric Cards (Dashboard):**
- Large number display: text-3xl font-bold
- Label below: text-sm text-gray-600
- Trend indicator with arrow icon and percentage
- Colored accent border-top (border-t-4)

### Forms & Inputs
**Input Fields:**
- Height: h-10
- Padding: px-4
- Border: border border-gray-300 rounded-md
- Focus: ring-2 ring-primary ring-offset-2
- Label above input: text-sm font-medium mb-2

**Select Dropdowns:**
- Styled consistently with text inputs
- Chevron icon right-aligned

**Filter Controls:**
- Horizontal layout with gap-4
- Compact height (h-9)
- Filter tags with remove icons

### Buttons
**Primary Actions:**
- bg-primary text-white
- Padding: px-6 py-2.5
- Rounded: rounded-md
- Font: text-sm font-semibold
- Shadow: shadow-sm

**Secondary Actions:**
- Border: border-2 border-gray-300
- Text: text-gray-700
- Background: bg-white

**Icon Buttons:**
- Square: w-9 h-9
- Centered icon: Heroicons w-5 h-5
- Hover background: hover:bg-gray-100

### Status Badges
- Rounded-full px-3 py-1 text-xs font-semibold
- Active: bg-green-100 text-green-800
- Inactive: bg-red-100 text-red-800
- Pending: bg-yellow-100 text-yellow-800
- Expiring Soon: bg-orange-100 text-orange-800

### Detail View
**Tabbed Interface:**
- Tab bar with border-b
- Active tab: border-b-2 border-primary text-primary font-semibold
- Inactive tabs: text-gray-600 hover:text-gray-900
- Tab content padding: pt-6

**Information Panels:**
- Label-value pairs in grid: grid-cols-2 gap-4
- Labels: text-sm font-medium text-gray-600
- Values: text-base text-gray-900

### Modals & Overlays
- Backdrop: bg-black bg-opacity-50
- Modal container: max-w-2xl bg-white rounded-lg
- Padding: p-6
- Header with title and close button
- Footer with action buttons right-aligned

---

## Page Layouts

### Dashboard
- 3-column metric cards at top (Total Vendors, Active Contracts, Avg Performance)
- Recent activity feed and upcoming renewals side-by-side
- Quick actions panel with "Add Vendor" and "New Contract" buttons

### Vendor Directory
- Search bar and filter controls at top
- Table view with columns: Name, Category, Status, Contract Count, Performance Rating, Actions
- Pagination at bottom

### Vendor Detail Page
- Header with vendor name, logo placeholder, and primary action buttons
- Tabbed sections: Overview, Contracts, Contacts, Performance, Documents
- Sidebar with quick stats and recent activity

### Contract Management
- Table with Contract Name, Vendor, Value, Start/End Dates, Status
- Visual indicators for contracts expiring within 30/60/90 days
- Renewal workflow actions

---

## Icons
**Library:** Heroicons (outline style) via CDN
- Navigation: home, users, document-text, chart-bar, cog
- Actions: plus, pencil, trash, eye, download
- Status: check-circle, x-circle, exclamation-triangle
- UI: search, filter, chevron-down, x-mark

---

## Accessibility
- Minimum contrast ratio 4.5:1 for all text
- Focus indicators visible on all interactive elements
- Semantic HTML with proper heading hierarchy
- ARIA labels for icon-only buttons
- Keyboard navigation support throughout

---

## Animations
**Minimal, purposeful motion:**
- Hover transitions: transition-all duration-150
- Modal fade-in: fade and scale
- No page transitions or scroll animations
- Loading spinners for async operations only