# Push Code to GitHub - Quick Instructions

## Step 1: Create Personal Access Token

1. Go to: https://github.com/settings/tokens
2. Click **"Generate new token (classic)"**
3. Give it a name: `VMS Push`
4. Select scope: **`repo`** (check the box)
5. Click **"Generate token"**
6. **COPY THE TOKEN** (you won't see it again!)

## Step 2: Push Using Token

Open PowerShell in the project directory and run:

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system

# Replace YOUR_TOKEN_HERE with your actual token
git remote set-url origin https://YOUR_TOKEN_HERE@github.com/rezaakm/vendor-management-system.git

git push -u origin main
```

**Example:**
```powershell
git remote set-url origin https://ghp_abc123xyz789@github.com/rezaakm/vendor-management-system.git
git push -u origin main
```

## Alternative: Use GitHub Desktop or GitHub CLI

If you have GitHub Desktop installed:
1. Open GitHub Desktop
2. File → Add Local Repository
3. Select: `C:\Users\reza\OneDrive\Desktop\vendor-management-system`
4. Click "Publish repository"

Or use GitHub CLI:
```powershell
gh auth login
git push -u origin main
```

## Verify Push

After pushing, check:
- Visit: https://github.com/rezaakm/vendor-management-system
- You should see all your files there!

