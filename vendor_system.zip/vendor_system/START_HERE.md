# 🚀 START HERE - Installation Steps

## Current Status

Based on your system, you need to:

1. ✅ **Install PostgreSQL** - You have the installer on Desktop
2. ⚠️ **Install Node.js** - Need to download and install
3. ⚠️ **Restart PowerShell** - After each installation
4. ⚠️ **Setup Database** - After both are installed

---

## 📥 STEP 1: Install PostgreSQL (You have this!)

**File on Desktop:** `postgresql-18.0-2-windows-x64.exe`

### Installation Steps:

1. **Double-click** `postgresql-18.0-2-windows-x64.exe` on your Desktop

2. **Follow the installer:**
   - Click "Next"
   - Installation directory: Keep default
   - Components: Keep all checked ✅
   - Data directory: Keep default
   - **Password:** Enter `postgres` (or remember your password!)
   - **Port:** Keep default `5432`
   - Click "Next" through remaining steps
   - Click "Install"
   - Wait for installation (3-5 minutes)
   - Click "Finish"

3. **⚠️ IMPORTANT:** Close and reopen PowerShell!

---

## 📥 STEP 2: Install Node.js (Download needed)

### Option A: Download from website

1. Go to: **https://nodejs.org/**
2. Click the big green button: **"Download Node.js (LTS)"**
3. Save the file to your Desktop
4. Double-click the downloaded `.msi` file
5. Follow installer (keep all defaults)
6. **⚠️ IMPORTANT:** Close and reopen PowerShell!

### Option B: Direct download link

**Latest LTS Version:**
- https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi

1. Download the file
2. Save to Desktop
3. Double-click to install
4. **⚠️ IMPORTANT:** Close and reopen PowerShell!

---

## ✅ STEP 3: Verify Installation

After installing both, **open a NEW PowerShell** and run:

```powershell
node --version    # Should show: v20.x.x
npm --version     # Should show: 10.x.x
psql --version    # Should show: psql (PostgreSQL) 18.x
```

If you see version numbers, you're good to go! 🎉

---

## 🗄️ STEP 4: Setup Database

After both are installed, create the VMS database:

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system
powershell -ExecutionPolicy Bypass -File .\setup-database.ps1
```

When prompted:
- Enter password: `postgres` (or your PostgreSQL password)

This will create:
- Database: `vms_db`
- User: `vms_user`
- Password: `vms_password`

---

## 🚀 STEP 5: Setup and Run VMS

Once everything is installed:

### Backend Setup:

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\backend
npm install
copy .env.example .env
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run start:dev
```

Wait for: `🚀 VMS Backend API is running on: http://localhost:3001`

### Frontend Setup (NEW PowerShell window):

```powershell
cd C:\Users\reza\OneDrive\Desktop\vendor-management-system\packages\frontend
npm install
echo NEXT_PUBLIC_API_URL=http://localhost:3001 > .env.local
npm run dev
```

Wait for: `Ready on http://localhost:3000`

---

## 🎉 Access the Application

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:3001
- **API Docs:** http://localhost:3001/api
- **Login:** admin@vms.com / admin123

---

## ⚠️ Troubleshooting

**If commands don't work after installation:**
- Close and reopen PowerShell
- Or restart your computer

**If Node.js not found:**
- Make sure "Add to PATH" was checked during installation
- Reinstall Node.js if needed

**If PostgreSQL not found:**
- Add to PATH manually: `C:\Program Files\PostgreSQL\18\bin`
- Or restart computer

---

## 📋 Quick Checklist

- [ ] PostgreSQL installer run
- [ ] PostgreSQL installed (password set)
- [ ] PowerShell restarted after PostgreSQL
- [ ] Node.js downloaded
- [ ] Node.js installed
- [ ] PowerShell restarted after Node.js
- [ ] All versions verified (`node --version`, `npm --version`, `psql --version`)
- [ ] Database setup complete
- [ ] Ready to run VMS!

---

**Need help?** Check `INSTALL_PREREQUISITES.md` for detailed troubleshooting.

